﻿using System;
using System.Data;
using System.Windows.Forms;

namespace EMS
{
	public partial class PerformanceReview : Form
	{
		private EMSDBDataSetTableAdapters.PerformanceReviewsTableAdapter reviewAdapter;
		private EMSDBDataSetTableAdapters.EmployeesTableAdapter empAdapter;

		public PerformanceReview()
		{
			InitializeComponent();
			this.AutoScroll = true;

			
			this.btnAddReview.Click += btnAddReview_Click;
			this.btnUpdate.Click += btnUpdate_Click;
			this.btnDelete.Click += btnDelete_Click;
			this.btnClear.Click += btnClear_Click;
			this.dataGridView1.CellClick += dataGridView1_CellClick;
			this.linklbDashboard.Click += linklbDashboard_Click;

			reviewAdapter = new EMSDBDataSetTableAdapters.PerformanceReviewsTableAdapter();
			empAdapter = new EMSDBDataSetTableAdapters.EmployeesTableAdapter();

			
			if (Session.Role != "Admin")
			{
				btnAddReview.Enabled = false;
				btnUpdate.Enabled = false;
				btnDelete.Enabled = false;
				btnClear.Enabled = false;
			}
		}

		
		private void PerformanceReview_Load(object sender, EventArgs e) => LoadReviews();
		private void label3_Click(object sender, EventArgs e) { }

		
		private void btnDelete_Click_1(object sender, EventArgs e) => btnDelete_Click(sender, e);

		
		private void LoadReviews()
		{
			try
			{
				this.performanceReviewsTableAdapter.Fill(this.eMSDBDataSet.PerformanceReviews);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading performance reviews: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnAddReview_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can add performance reviews.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (!int.TryParse(txtEmployee.Text, out int empID))
			{
				MessageBox.Show("Please enter a valid numeric Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				var empTable = empAdapter.GetData();
				if (empTable.FindByEmployeeID(empID) == null)
				{
					MessageBox.Show("Employee ID not found. Please enter a valid Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error verifying employee: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			string reviewer = txtReviwer.Text.Trim();
			if (string.IsNullOrEmpty(reviewer))
			{
				MessageBox.Show("Reviewer name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string period = cmdPeriod.SelectedItem?.ToString();
			if (string.IsNullOrEmpty(period))
			{
				MessageBox.Show("Please select a review period.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int rating = (int)nudRating.Value;
			string comments = rtxtComments.Text.Trim();

			try
			{
				reviewAdapter.Insert(empID, dtpReview.Value.Date, reviewer, rating,
									 string.IsNullOrEmpty(comments) ? null : comments, period);
				LoadReviews();
				ClearFields();
				MessageBox.Show("Performance review added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error adding review: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnUpdate_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can update performance reviews.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a review to update.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int reviewID = (int)dataGridView1.CurrentRow.Cells["reviewIDDataGridViewTextBoxColumn"].Value;
			int oldEmpID = (int)dataGridView1.CurrentRow.Cells["employeeIDDataGridViewTextBoxColumn"].Value;
			DateTime oldDate = (DateTime)dataGridView1.CurrentRow.Cells["reviewDateDataGridViewTextBoxColumn"].Value;
			string oldReviewer = dataGridView1.CurrentRow.Cells["reviewerDataGridViewTextBoxColumn"].Value?.ToString();
			int oldRating = (int)dataGridView1.CurrentRow.Cells["ratingDataGridViewTextBoxColumn"].Value;
			string oldComments = dataGridView1.CurrentRow.Cells["commentsDataGridViewTextBoxColumn"].Value?.ToString();
			string oldPeriod = dataGridView1.CurrentRow.Cells["reviewPeriodDataGridViewTextBoxColumn"].Value.ToString();

			if (!int.TryParse(txtEmployee.Text, out int empID))
			{
				MessageBox.Show("Please enter a valid numeric Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string reviewer = txtReviwer.Text.Trim();
			if (string.IsNullOrEmpty(reviewer))
			{
				MessageBox.Show("Reviewer name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string period = cmdPeriod.SelectedItem?.ToString();
			if (string.IsNullOrEmpty(period))
			{
				MessageBox.Show("Please select a review period.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int rating = (int)nudRating.Value;
			string comments = rtxtComments.Text.Trim();

			try
			{
				reviewAdapter.Update(empID, dtpReview.Value.Date, reviewer, rating,
									 string.IsNullOrEmpty(comments) ? null : comments, period,
									 reviewID, oldEmpID, oldDate, oldReviewer, oldRating, oldComments, oldPeriod);
				LoadReviews();
				ClearFields();
				MessageBox.Show("Performance review updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error updating review: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can delete performance reviews.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a review to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (MessageBox.Show("Are you sure you want to delete this performance review?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				int reviewID = (int)dataGridView1.CurrentRow.Cells["reviewIDDataGridViewTextBoxColumn"].Value;
				try
				{
					reviewAdapter.Delete(reviewID, 0, DateTime.Now, "", 0, "", "");
					LoadReviews();
					ClearFields();
					MessageBox.Show("Performance review deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error deleting review: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		
		private void btnClear_Click(object sender, EventArgs e) => ClearFields();

		
		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
				txtEmployee.Text = row.Cells["employeeIDDataGridViewTextBoxColumn"].Value.ToString();
				dtpReview.Value = (DateTime)row.Cells["reviewDateDataGridViewTextBoxColumn"].Value;
				txtReviwer.Text = row.Cells["reviewerDataGridViewTextBoxColumn"].Value?.ToString();
				nudRating.Value = (int)row.Cells["ratingDataGridViewTextBoxColumn"].Value;
				rtxtComments.Text = row.Cells["commentsDataGridViewTextBoxColumn"].Value?.ToString();
				cmdPeriod.SelectedItem = row.Cells["reviewPeriodDataGridViewTextBoxColumn"].Value.ToString();
			}
		}

		
		private void ClearFields()
		{
			txtEmployee.Clear();
			txtReviwer.Clear();
			nudRating.Value = 3;
			rtxtComments.Clear();
			cmdPeriod.SelectedIndex = -1;
			dtpReview.Value = DateTime.Now;
		}

		
		private void linklbDashboard_Click(object sender, EventArgs e) => this.Close();
	}
}