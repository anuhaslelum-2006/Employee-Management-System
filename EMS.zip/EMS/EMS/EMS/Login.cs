﻿using System;
using System.Windows.Forms;

namespace EMS
{
	public partial class Login : Form
	{
		public Login()
		{
			InitializeComponent();

			
			this.btnLogin.Click += btnLogin_Click;
			this.lbClear.Click += lbClear_Click;
			this.btnExit.Click += btnExit_Click;
		}

		
		private void Login_Load(object sender, EventArgs e) { }

		private void btnLogin_Click(object sender, EventArgs e)
		{
			string username = txtUsername.Text.Trim();
			string password = txtPassword.Text;

			if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
			{
				MessageBox.Show("Please enter username and password.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			var userAdapter = new EMSDBDataSetTableAdapters.UsersTableAdapter();
			var dt = userAdapter.GetData();

			EMSDBDataSet.UsersRow foundUser = null;
			foreach (EMSDBDataSet.UsersRow row in dt)
			{
				if (row.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && row.PasswordHash == password)
				{
					foundUser = row;
					break;
				}
			}

			if (foundUser != null)
			{
				Session.UserID = foundUser.UserID;
				Session.Username = foundUser.Username;
				Session.Role = foundUser.Role;

				MessageBox.Show($"Welcome {foundUser.Username}!", "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				Main mainForm = new Main();
				mainForm.Show();
				this.Hide();
			}
			else
			{
				MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void lbClear_Click(object sender, EventArgs e)
		{
			txtUsername.Clear();
			txtPassword.Clear();
			txtUsername.Focus();
		}

		
		private void btnExit_Click(object sender, EventArgs e)
		{
			DialogResult result = MessageBox.Show("Are you sure you want to exit the application?", "Confirm Exit",
				MessageBoxButtons.YesNo, MessageBoxIcon.Question);

			if (result == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbTitle_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}