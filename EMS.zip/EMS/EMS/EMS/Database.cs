﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace EMS
{
	public class Database
	{
		private String ConnectionString = "Data Source=localhost;Initial Catalog=EMSDB;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";


		public SqlConnection GetConnection()

		{
			return new SqlConnection(ConnectionString);
	}
		
	}
}
