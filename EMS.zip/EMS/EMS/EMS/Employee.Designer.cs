﻿namespace EMS
{
	partial class Employee
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.panelEmployee = new System.Windows.Forms.Panel();
			this.btnDelete = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnUpdate = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.dtpHireDate = new System.Windows.Forms.DateTimePicker();
			this.txtLastName = new System.Windows.Forms.TextBox();
			this.txtPosition = new System.Windows.Forms.TextBox();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.txtSalary = new System.Windows.Forms.TextBox();
			this.txtPhone = new System.Windows.Forms.TextBox();
			this.txtFirstName = new System.Windows.Forms.TextBox();
			this.lbLastName = new System.Windows.Forms.Label();
			this.lbPosition = new System.Windows.Forms.Label();
			this.lbEmail = new System.Windows.Forms.Label();
			this.lbPhone = new System.Windows.Forms.Label();
			this.lbHireDate = new System.Windows.Forms.Label();
			this.lbSalary = new System.Windows.Forms.Label();
			this.lbFirstName = new System.Windows.Forms.Label();
			this.dgvEmployee = new System.Windows.Forms.DataGridView();
			this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.hireDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.basicSalaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSet = new EMS.EMSDBDataSet();
			this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
			this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
			this.lbSearch = new System.Windows.Forms.Label();
			this.txtSearch = new System.Windows.Forms.TextBox();
			this.btnSearch = new System.Windows.Forms.Button();
			this.employeesTableAdapter = new EMS.EMSDBDataSetTableAdapters.EmployeesTableAdapter();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			this.panelEmployee.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSetBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).BeginInit();
			this.fillByToolStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelEmployee
			// 
			this.panelEmployee.Controls.Add(this.linklbDashboard);
			this.panelEmployee.Controls.Add(this.btnDelete);
			this.panelEmployee.Controls.Add(this.btnClear);
			this.panelEmployee.Controls.Add(this.btnUpdate);
			this.panelEmployee.Controls.Add(this.btnAdd);
			this.panelEmployee.Controls.Add(this.dtpHireDate);
			this.panelEmployee.Controls.Add(this.txtLastName);
			this.panelEmployee.Controls.Add(this.txtPosition);
			this.panelEmployee.Controls.Add(this.txtEmail);
			this.panelEmployee.Controls.Add(this.txtSalary);
			this.panelEmployee.Controls.Add(this.txtPhone);
			this.panelEmployee.Controls.Add(this.txtFirstName);
			this.panelEmployee.Controls.Add(this.lbLastName);
			this.panelEmployee.Controls.Add(this.lbPosition);
			this.panelEmployee.Controls.Add(this.lbEmail);
			this.panelEmployee.Controls.Add(this.lbPhone);
			this.panelEmployee.Controls.Add(this.lbHireDate);
			this.panelEmployee.Controls.Add(this.lbSalary);
			this.panelEmployee.Controls.Add(this.lbFirstName);
			this.panelEmployee.Location = new System.Drawing.Point(12, 52);
			this.panelEmployee.Name = "panelEmployee";
			this.panelEmployee.Size = new System.Drawing.Size(622, 257);
			this.panelEmployee.TabIndex = 0;
			this.panelEmployee.Paint += new System.Windows.Forms.PaintEventHandler(this.panelEmployee_Paint);
			// 
			// btnDelete
			// 
			this.btnDelete.BackColor = System.Drawing.Color.LightCoral;
			this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDelete.Location = new System.Drawing.Point(446, 187);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(80, 25);
			this.btnDelete.TabIndex = 17;
			this.btnDelete.Text = "Delete";
			this.btnDelete.UseVisualStyleBackColor = false;
			// 
			// btnClear
			// 
			this.btnClear.BackColor = System.Drawing.Color.LightGray;
			this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClear.Location = new System.Drawing.Point(331, 187);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(80, 25);
			this.btnClear.TabIndex = 16;
			this.btnClear.Text = "Clear";
			this.btnClear.UseVisualStyleBackColor = false;
			// 
			// btnUpdate
			// 
			this.btnUpdate.BackColor = System.Drawing.Color.LightCyan;
			this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnUpdate.Location = new System.Drawing.Point(216, 187);
			this.btnUpdate.Name = "btnUpdate";
			this.btnUpdate.Size = new System.Drawing.Size(80, 25);
			this.btnUpdate.TabIndex = 15;
			this.btnUpdate.Text = "Update";
			this.btnUpdate.UseVisualStyleBackColor = false;
			// 
			// btnAdd
			// 
			this.btnAdd.BackColor = System.Drawing.Color.Aquamarine;
			this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAdd.Location = new System.Drawing.Point(104, 187);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(80, 25);
			this.btnAdd.TabIndex = 14;
			this.btnAdd.Text = "Add";
			this.btnAdd.UseVisualStyleBackColor = false;
			// 
			// dtpHireDate
			// 
			this.dtpHireDate.Location = new System.Drawing.Point(432, 102);
			this.dtpHireDate.Name = "dtpHireDate";
			this.dtpHireDate.Size = new System.Drawing.Size(150, 22);
			this.dtpHireDate.TabIndex = 13;
			// 
			// txtLastName
			// 
			this.txtLastName.Location = new System.Drawing.Point(432, 17);
			this.txtLastName.Name = "txtLastName";
			this.txtLastName.Size = new System.Drawing.Size(150, 22);
			this.txtLastName.TabIndex = 12;
			// 
			// txtPosition
			// 
			this.txtPosition.Location = new System.Drawing.Point(144, 60);
			this.txtPosition.Name = "txtPosition";
			this.txtPosition.Size = new System.Drawing.Size(150, 22);
			this.txtPosition.TabIndex = 11;
			// 
			// txtEmail
			// 
			this.txtEmail.Location = new System.Drawing.Point(432, 58);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(150, 22);
			this.txtEmail.TabIndex = 10;
			// 
			// txtSalary
			// 
			this.txtSalary.Location = new System.Drawing.Point(144, 148);
			this.txtSalary.Name = "txtSalary";
			this.txtSalary.Size = new System.Drawing.Size(150, 22);
			this.txtSalary.TabIndex = 9;
			// 
			// txtPhone
			// 
			this.txtPhone.Location = new System.Drawing.Point(144, 104);
			this.txtPhone.Name = "txtPhone";
			this.txtPhone.Size = new System.Drawing.Size(150, 22);
			this.txtPhone.TabIndex = 8;
			// 
			// txtFirstName
			// 
			this.txtFirstName.Location = new System.Drawing.Point(146, 16);
			this.txtFirstName.Name = "txtFirstName";
			this.txtFirstName.Size = new System.Drawing.Size(150, 22);
			this.txtFirstName.TabIndex = 7;
			// 
			// lbLastName
			// 
			this.lbLastName.AutoSize = true;
			this.lbLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbLastName.Location = new System.Drawing.Point(320, 13);
			this.lbLastName.Name = "lbLastName";
			this.lbLastName.Size = new System.Drawing.Size(91, 20);
			this.lbLastName.TabIndex = 6;
			this.lbLastName.Text = "Last Name";
			// 
			// lbPosition
			// 
			this.lbPosition.AutoSize = true;
			this.lbPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbPosition.Location = new System.Drawing.Point(21, 60);
			this.lbPosition.Name = "lbPosition";
			this.lbPosition.Size = new System.Drawing.Size(69, 20);
			this.lbPosition.TabIndex = 5;
			this.lbPosition.Text = "Position";
			// 
			// lbEmail
			// 
			this.lbEmail.AutoSize = true;
			this.lbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbEmail.Location = new System.Drawing.Point(320, 58);
			this.lbEmail.Name = "lbEmail";
			this.lbEmail.Size = new System.Drawing.Size(51, 20);
			this.lbEmail.TabIndex = 4;
			this.lbEmail.Text = "Email";
			// 
			// lbPhone
			// 
			this.lbPhone.AutoSize = true;
			this.lbPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbPhone.Location = new System.Drawing.Point(21, 106);
			this.lbPhone.Name = "lbPhone";
			this.lbPhone.Size = new System.Drawing.Size(56, 20);
			this.lbPhone.TabIndex = 3;
			this.lbPhone.Text = "Phone";
			// 
			// lbHireDate
			// 
			this.lbHireDate.AutoSize = true;
			this.lbHireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbHireDate.Location = new System.Drawing.Point(320, 104);
			this.lbHireDate.Name = "lbHireDate";
			this.lbHireDate.Size = new System.Drawing.Size(82, 20);
			this.lbHireDate.TabIndex = 2;
			this.lbHireDate.Text = "Hire Date";
			// 
			// lbSalary
			// 
			this.lbSalary.AutoSize = true;
			this.lbSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbSalary.Location = new System.Drawing.Point(21, 150);
			this.lbSalary.Name = "lbSalary";
			this.lbSalary.Size = new System.Drawing.Size(56, 20);
			this.lbSalary.TabIndex = 1;
			this.lbSalary.Text = "Salary";
			// 
			// lbFirstName
			// 
			this.lbFirstName.AutoSize = true;
			this.lbFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbFirstName.Location = new System.Drawing.Point(21, 13);
			this.lbFirstName.Name = "lbFirstName";
			this.lbFirstName.Size = new System.Drawing.Size(92, 20);
			this.lbFirstName.TabIndex = 0;
			this.lbFirstName.Text = "First Name";
			// 
			// dgvEmployee
			// 
			this.dgvEmployee.AutoGenerateColumns = false;
			this.dgvEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvEmployee.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.positionDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.hireDateDataGridViewTextBoxColumn,
            this.basicSalaryDataGridViewTextBoxColumn});
			this.dgvEmployee.DataSource = this.employeesBindingSource;
			this.dgvEmployee.Location = new System.Drawing.Point(12, 354);
			this.dgvEmployee.Name = "dgvEmployee";
			this.dgvEmployee.RowHeadersWidth = 51;
			this.dgvEmployee.RowTemplate.Height = 24;
			this.dgvEmployee.Size = new System.Drawing.Size(622, 168);
			this.dgvEmployee.TabIndex = 1;
			this.dgvEmployee.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
			// 
			// employeeIDDataGridViewTextBoxColumn
			// 
			this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
			this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
			this.employeeIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// firstNameDataGridViewTextBoxColumn
			// 
			this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
			this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
			this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
			this.firstNameDataGridViewTextBoxColumn.Width = 125;
			// 
			// lastNameDataGridViewTextBoxColumn
			// 
			this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
			this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
			this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
			this.lastNameDataGridViewTextBoxColumn.Width = 125;
			// 
			// positionDataGridViewTextBoxColumn
			// 
			this.positionDataGridViewTextBoxColumn.DataPropertyName = "Position";
			this.positionDataGridViewTextBoxColumn.HeaderText = "Position";
			this.positionDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
			this.positionDataGridViewTextBoxColumn.Width = 125;
			// 
			// emailDataGridViewTextBoxColumn
			// 
			this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
			this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
			this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
			this.emailDataGridViewTextBoxColumn.Width = 125;
			// 
			// phoneDataGridViewTextBoxColumn
			// 
			this.phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
			this.phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
			this.phoneDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
			this.phoneDataGridViewTextBoxColumn.Width = 125;
			// 
			// hireDateDataGridViewTextBoxColumn
			// 
			this.hireDateDataGridViewTextBoxColumn.DataPropertyName = "HireDate";
			this.hireDateDataGridViewTextBoxColumn.HeaderText = "HireDate";
			this.hireDateDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.hireDateDataGridViewTextBoxColumn.Name = "hireDateDataGridViewTextBoxColumn";
			this.hireDateDataGridViewTextBoxColumn.Width = 125;
			// 
			// basicSalaryDataGridViewTextBoxColumn
			// 
			this.basicSalaryDataGridViewTextBoxColumn.DataPropertyName = "BasicSalary";
			this.basicSalaryDataGridViewTextBoxColumn.HeaderText = "BasicSalary";
			this.basicSalaryDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.basicSalaryDataGridViewTextBoxColumn.Name = "basicSalaryDataGridViewTextBoxColumn";
			this.basicSalaryDataGridViewTextBoxColumn.Width = 125;
			// 
			// employeesBindingSource
			// 
			this.employeesBindingSource.DataMember = "Employees";
			this.employeesBindingSource.DataSource = this.eMSDBDataSetBindingSource;
			// 
			// eMSDBDataSetBindingSource
			// 
			this.eMSDBDataSetBindingSource.DataSource = this.eMSDBDataSet;
			this.eMSDBDataSetBindingSource.Position = 0;
			// 
			// eMSDBDataSet
			// 
			this.eMSDBDataSet.DataSetName = "EMSDBDataSet";
			this.eMSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// fillByToolStrip
			// 
			this.fillByToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton});
			this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
			this.fillByToolStrip.Name = "fillByToolStrip";
			this.fillByToolStrip.Size = new System.Drawing.Size(677, 31);
			this.fillByToolStrip.TabIndex = 2;
			this.fillByToolStrip.Text = "fillByToolStrip";
			// 
			// fillByToolStripButton
			// 
			this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.fillByToolStripButton.Name = "fillByToolStripButton";
			this.fillByToolStripButton.Size = new System.Drawing.Size(48, 28);
			this.fillByToolStripButton.Text = "FillBy";
			this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
			// 
			// lbSearch
			// 
			this.lbSearch.AutoSize = true;
			this.lbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbSearch.Location = new System.Drawing.Point(63, 323);
			this.lbSearch.Name = "lbSearch";
			this.lbSearch.Size = new System.Drawing.Size(62, 20);
			this.lbSearch.TabIndex = 18;
			this.lbSearch.Text = "Search";
			// 
			// txtSearch
			// 
			this.txtSearch.Location = new System.Drawing.Point(158, 323);
			this.txtSearch.Name = "txtSearch";
			this.txtSearch.Size = new System.Drawing.Size(200, 22);
			this.txtSearch.TabIndex = 18;
			// 
			// btnSearch
			// 
			this.btnSearch.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSearch.Location = new System.Drawing.Point(399, 323);
			this.btnSearch.Name = "btnSearch";
			this.btnSearch.Size = new System.Drawing.Size(102, 25);
			this.btnSearch.TabIndex = 18;
			this.btnSearch.Text = "Search";
			this.btnSearch.UseVisualStyleBackColor = false;
			// 
			// employeesTableAdapter
			// 
			this.employeesTableAdapter.ClearBeforeFill = true;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(13, 225);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 18;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// Employee
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(677, 549);
			this.Controls.Add(this.btnSearch);
			this.Controls.Add(this.txtSearch);
			this.Controls.Add(this.lbSearch);
			this.Controls.Add(this.fillByToolStrip);
			this.Controls.Add(this.dgvEmployee);
			this.Controls.Add(this.panelEmployee);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Employee";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Employee";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.Employee_Load);
			this.panelEmployee.ResumeLayout(false);
			this.panelEmployee.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSetBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).EndInit();
			this.fillByToolStrip.ResumeLayout(false);
			this.fillByToolStrip.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panelEmployee;
		private System.Windows.Forms.Label lbFirstName;
		private System.Windows.Forms.Label lbLastName;
		private System.Windows.Forms.Label lbPosition;
		private System.Windows.Forms.Label lbEmail;
		private System.Windows.Forms.Label lbPhone;
		private System.Windows.Forms.Label lbHireDate;
		private System.Windows.Forms.Label lbSalary;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.DateTimePicker dtpHireDate;
		private System.Windows.Forms.TextBox txtLastName;
		private System.Windows.Forms.TextBox txtPosition;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.TextBox txtSalary;
		private System.Windows.Forms.TextBox txtPhone;
		private System.Windows.Forms.TextBox txtFirstName;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnUpdate;
		private System.Windows.Forms.DataGridView dgvEmployee;
		private System.Windows.Forms.BindingSource eMSDBDataSetBindingSource;
		private EMSDBDataSet eMSDBDataSet;
		private System.Windows.Forms.BindingSource employeesBindingSource;
		private EMSDBDataSetTableAdapters.EmployeesTableAdapter employeesTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn hireDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn basicSalaryDataGridViewTextBoxColumn;
		private System.Windows.Forms.ToolStrip fillByToolStrip;
		private System.Windows.Forms.ToolStripButton fillByToolStripButton;
		private System.Windows.Forms.Label lbSearch;
		private System.Windows.Forms.TextBox txtSearch;
		private System.Windows.Forms.Button btnSearch;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}