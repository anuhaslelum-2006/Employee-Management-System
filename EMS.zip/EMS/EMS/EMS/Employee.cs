﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace EMS
{
	public partial class Employee : Form
	{
		private EMSDBDataSetTableAdapters.EmployeesTableAdapter empAdapter;
		private EMSDBDataSet.EmployeesDataTable empTable;

		public Employee()
		{
			InitializeComponent();
			this.AutoScroll = true;

			
			this.btnAdd.Click += btnAdd_Click;
			this.btnUpdate.Click += btnUpdate_Click;
			this.btnClear.Click += btnClear_Click;
			this.btnDelete.Click += btnDelete_Click;
			this.btnSearch.Click += btnSearch_Click;
			this.dgvEmployee.CellClick += dgvEmployee_CellClick;
			this.fillByToolStripButton.Click += fillByToolStripButton_Click;
			this.linklbDashboard.Click += linklbDashboard_Click;

			empAdapter = new EMSDBDataSetTableAdapters.EmployeesTableAdapter();

		
			if (Session.Role != "Admin")
			{
				btnAdd.Enabled = false;
				btnUpdate.Enabled = false;
				btnDelete.Enabled = false;
				btnClear.Enabled = false;
			}
		}

		
		private void Employee_Load(object sender, EventArgs e) => LoadEmployees();

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }

		private void panelEmployee_Paint(object sender, PaintEventArgs e) { }

		private void fillByToolStripButton_Click(object sender, EventArgs e)
		{
			try
			{
				this.employeesTableAdapter.FillBy(this.eMSDBDataSet.Employees);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void LoadEmployees()
		{
			empTable = empAdapter.GetData();
			employeesBindingSource.DataSource = empTable;
		}

		
		private void btnAdd_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can add employees.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text))
			{
				MessageBox.Show("First Name and Last Name are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (!decimal.TryParse(txtSalary.Text, out decimal salary))
			{
				MessageBox.Show("Invalid salary amount.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				empAdapter.Insert(
					txtFirstName.Text.Trim(),
					txtLastName.Text.Trim(),
					string.IsNullOrWhiteSpace(txtPosition.Text) ? null : txtPosition.Text.Trim(),
					string.IsNullOrWhiteSpace(txtEmail.Text) ? null : txtEmail.Text.Trim(),
					string.IsNullOrWhiteSpace(txtPhone.Text) ? null : txtPhone.Text.Trim(),
					dtpHireDate.Checked ? dtpHireDate.Value : (DateTime?)null,
					salary
				);
				LoadEmployees();
				ClearFields();
				MessageBox.Show("Employee added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnUpdate_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can update employees.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dgvEmployee.CurrentRow == null)
			{
				MessageBox.Show("Please select an employee to update.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int empID = (int)dgvEmployee.CurrentRow.Cells["employeeIDDataGridViewTextBoxColumn"].Value;

			if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text))
			{
				MessageBox.Show("First Name and Last Name are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (!decimal.TryParse(txtSalary.Text, out decimal salary))
			{
				MessageBox.Show("Invalid salary amount.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				empAdapter.Update(
					txtFirstName.Text.Trim(),
					txtLastName.Text.Trim(),
					string.IsNullOrWhiteSpace(txtPosition.Text) ? null : txtPosition.Text.Trim(),
					string.IsNullOrWhiteSpace(txtEmail.Text) ? null : txtEmail.Text.Trim(),
					string.IsNullOrWhiteSpace(txtPhone.Text) ? null : txtPhone.Text.Trim(),
					dtpHireDate.Checked ? dtpHireDate.Value : (DateTime?)null,
					salary,
					empID,
					txtFirstName.Text.Trim(),
					txtLastName.Text.Trim(),
					string.IsNullOrWhiteSpace(txtPosition.Text) ? null : txtPosition.Text.Trim(),
					string.IsNullOrWhiteSpace(txtEmail.Text) ? null : txtEmail.Text.Trim(),
					string.IsNullOrWhiteSpace(txtPhone.Text) ? null : txtPhone.Text.Trim(),
					dtpHireDate.Checked ? dtpHireDate.Value : (DateTime?)null,
					salary,
					empID
				);
				LoadEmployees();
				ClearFields();
				MessageBox.Show("Employee updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can delete employees.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dgvEmployee.CurrentRow == null)
			{
				MessageBox.Show("Please select an employee to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (MessageBox.Show("Are you sure you want to delete this employee?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				int empID = (int)dgvEmployee.CurrentRow.Cells["employeeIDDataGridViewTextBoxColumn"].Value;
				try
				{
					empAdapter.Delete(empID, "", "", null, null, null, null, 0);
					LoadEmployees();
					ClearFields();
					MessageBox.Show("Employee deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		
		private void btnClear_Click(object sender, EventArgs e) => ClearFields();

		
		private void btnSearch_Click(object sender, EventArgs e)
		{
			string keyword = txtSearch.Text.Trim();
			if (string.IsNullOrEmpty(keyword))
			{
				LoadEmployees();
				return;
			}

			var filtered = empTable.Where(r => r.FirstName.Contains(keyword) ||
											   r.LastName.Contains(keyword) ||
											   (r.Position != null && r.Position.Contains(keyword)) ||
											   (r.Email != null && r.Email.Contains(keyword)) ||
											   (r.Phone != null && r.Phone.Contains(keyword)));
			EMSDBDataSet.EmployeesDataTable filteredTable = new EMSDBDataSet.EmployeesDataTable();
			foreach (var row in filtered)
				filteredTable.ImportRow(row);
			employeesBindingSource.DataSource = filteredTable;
		}

		
		private void ClearFields()
		{
			txtFirstName.Clear();
			txtLastName.Clear();
			txtPosition.Clear();
			txtEmail.Clear();
			txtPhone.Clear();
			txtSalary.Clear();
			dtpHireDate.Value = DateTime.Now;
		}

		private void dgvEmployee_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dgvEmployee.Rows[e.RowIndex];
				txtFirstName.Text = row.Cells["firstNameDataGridViewTextBoxColumn"].Value.ToString();
				txtLastName.Text = row.Cells["lastNameDataGridViewTextBoxColumn"].Value.ToString();
				txtPosition.Text = row.Cells["positionDataGridViewTextBoxColumn"].Value?.ToString();
				txtEmail.Text = row.Cells["emailDataGridViewTextBoxColumn"].Value?.ToString();
				txtPhone.Text = row.Cells["phoneDataGridViewTextBoxColumn"].Value?.ToString();
				txtSalary.Text = row.Cells["basicSalaryDataGridViewTextBoxColumn"].Value.ToString();
				dtpHireDate.Value = row.Cells["hireDateDataGridViewTextBoxColumn"].Value == DBNull.Value
									? DateTime.Now
									: Convert.ToDateTime(row.Cells["hireDateDataGridViewTextBoxColumn"].Value);
			}
		}

		
		private void linklbDashboard_Click(object sender, EventArgs e) => this.Close();
	}
}