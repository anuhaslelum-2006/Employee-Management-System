﻿namespace EMS
{
	partial class PasswordChange
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbOld = new System.Windows.Forms.Label();
			this.lbConfirm = new System.Windows.Forms.Label();
			this.lbNew = new System.Windows.Forms.Label();
			this.txtOld = new System.Windows.Forms.TextBox();
			this.txtNew = new System.Windows.Forms.TextBox();
			this.txtConfirm = new System.Windows.Forms.TextBox();
			this.btnSaveChanges = new System.Windows.Forms.Button();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// lbOld
			// 
			this.lbOld.AutoSize = true;
			this.lbOld.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbOld.Location = new System.Drawing.Point(40, 29);
			this.lbOld.Name = "lbOld";
			this.lbOld.Size = new System.Drawing.Size(122, 22);
			this.lbOld.TabIndex = 0;
			this.lbOld.Text = "Old Password";
			// 
			// lbConfirm
			// 
			this.lbConfirm.AutoSize = true;
			this.lbConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbConfirm.Location = new System.Drawing.Point(40, 115);
			this.lbConfirm.Name = "lbConfirm";
			this.lbConfirm.Size = new System.Drawing.Size(156, 22);
			this.lbConfirm.TabIndex = 1;
			this.lbConfirm.Text = "Confirm Password";
			// 
			// lbNew
			// 
			this.lbNew.AutoSize = true;
			this.lbNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbNew.Location = new System.Drawing.Point(40, 73);
			this.lbNew.Name = "lbNew";
			this.lbNew.Size = new System.Drawing.Size(130, 22);
			this.lbNew.TabIndex = 2;
			this.lbNew.Text = "New Password";
			// 
			// txtOld
			// 
			this.txtOld.Location = new System.Drawing.Point(255, 29);
			this.txtOld.Name = "txtOld";
			this.txtOld.PasswordChar = '*';
			this.txtOld.Size = new System.Drawing.Size(200, 22);
			this.txtOld.TabIndex = 3;
			// 
			// txtNew
			// 
			this.txtNew.Location = new System.Drawing.Point(255, 73);
			this.txtNew.Name = "txtNew";
			this.txtNew.PasswordChar = '*';
			this.txtNew.Size = new System.Drawing.Size(200, 22);
			this.txtNew.TabIndex = 4;
			// 
			// txtConfirm
			// 
			this.txtConfirm.Location = new System.Drawing.Point(255, 115);
			this.txtConfirm.Name = "txtConfirm";
			this.txtConfirm.PasswordChar = '*';
			this.txtConfirm.Size = new System.Drawing.Size(200, 22);
			this.txtConfirm.TabIndex = 5;
			// 
			// btnSaveChanges
			// 
			this.btnSaveChanges.BackColor = System.Drawing.Color.DarkOrange;
			this.btnSaveChanges.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSaveChanges.Location = new System.Drawing.Point(145, 161);
			this.btnSaveChanges.Name = "btnSaveChanges";
			this.btnSaveChanges.Size = new System.Drawing.Size(225, 30);
			this.btnSaveChanges.TabIndex = 6;
			this.btnSaveChanges.Text = "Save Changes ";
			this.btnSaveChanges.UseVisualStyleBackColor = false;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(2, 180);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 19;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// PasswordChange
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(528, 205);
			this.Controls.Add(this.linklbDashboard);
			this.Controls.Add(this.btnSaveChanges);
			this.Controls.Add(this.txtConfirm);
			this.Controls.Add(this.txtNew);
			this.Controls.Add(this.txtOld);
			this.Controls.Add(this.lbNew);
			this.Controls.Add(this.lbConfirm);
			this.Controls.Add(this.lbOld);
			this.Name = "PasswordChange";
			this.Text = "PasswordChange";
			this.Load += new System.EventHandler(this.PasswordChange_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lbOld;
		private System.Windows.Forms.Label lbConfirm;
		private System.Windows.Forms.Label lbNew;
		private System.Windows.Forms.TextBox txtOld;
		private System.Windows.Forms.TextBox txtNew;
		private System.Windows.Forms.TextBox txtConfirm;
		private System.Windows.Forms.Button btnSaveChanges;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}