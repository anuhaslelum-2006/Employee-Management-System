﻿namespace EMS
{
	partial class LeaveRequest
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label1 = new System.Windows.Forms.Label();
			this.panelLeave = new System.Windows.Forms.Panel();
			this.btnApprove = new System.Windows.Forms.Button();
			this.btnReject = new System.Windows.Forms.Button();
			this.btnDelete = new System.Windows.Forms.Button();
			this.btnRequest = new System.Windows.Forms.Button();
			this.cmdLeave = new System.Windows.Forms.ComboBox();
			this.dtpEnd = new System.Windows.Forms.DateTimePicker();
			this.dtpStart = new System.Windows.Forms.DateTimePicker();
			this.txtReason = new System.Windows.Forms.TextBox();
			this.txtEmployee = new System.Windows.Forms.TextBox();
			this.lbLeave = new System.Windows.Forms.Label();
			this.lbStart = new System.Windows.Forms.Label();
			this.lbReason = new System.Windows.Forms.Label();
			this.lbEnd = new System.Windows.Forms.Label();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.leaveIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.leaveTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.reasonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.leaveRequestsBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSet = new EMS.EMSDBDataSet();
			this.leaveRequestsTableAdapter = new EMS.EMSDBDataSetTableAdapters.LeaveRequestsTableAdapter();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			this.panelLeave.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.leaveRequestsBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(42, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(82, 20);
			this.label1.TabIndex = 0;
			this.label1.Text = "Employee";
			// 
			// panelLeave
			// 
			this.panelLeave.Controls.Add(this.btnApprove);
			this.panelLeave.Controls.Add(this.btnReject);
			this.panelLeave.Controls.Add(this.btnDelete);
			this.panelLeave.Controls.Add(this.btnRequest);
			this.panelLeave.Controls.Add(this.cmdLeave);
			this.panelLeave.Controls.Add(this.dtpEnd);
			this.panelLeave.Controls.Add(this.dtpStart);
			this.panelLeave.Controls.Add(this.txtReason);
			this.panelLeave.Controls.Add(this.txtEmployee);
			this.panelLeave.Controls.Add(this.lbLeave);
			this.panelLeave.Controls.Add(this.lbStart);
			this.panelLeave.Controls.Add(this.lbReason);
			this.panelLeave.Controls.Add(this.lbEnd);
			this.panelLeave.Controls.Add(this.label1);
			this.panelLeave.Location = new System.Drawing.Point(24, 12);
			this.panelLeave.Name = "panelLeave";
			this.panelLeave.Size = new System.Drawing.Size(624, 253);
			this.panelLeave.TabIndex = 1;
			// 
			// btnApprove
			// 
			this.btnApprove.BackColor = System.Drawing.Color.LawnGreen;
			this.btnApprove.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnApprove.Location = new System.Drawing.Point(166, 183);
			this.btnApprove.Name = "btnApprove";
			this.btnApprove.Size = new System.Drawing.Size(132, 33);
			this.btnApprove.TabIndex = 13;
			this.btnApprove.Text = "Approve";
			this.btnApprove.UseVisualStyleBackColor = false;
			this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click_1);
			// 
			// btnReject
			// 
			this.btnReject.BackColor = System.Drawing.Color.Coral;
			this.btnReject.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReject.Location = new System.Drawing.Point(318, 183);
			this.btnReject.Name = "btnReject";
			this.btnReject.Size = new System.Drawing.Size(132, 33);
			this.btnReject.TabIndex = 12;
			this.btnReject.Text = "Reject";
			this.btnReject.UseVisualStyleBackColor = false;
			this.btnReject.Click += new System.EventHandler(this.btnReject_Click_1);
			// 
			// btnDelete
			// 
			this.btnDelete.BackColor = System.Drawing.Color.IndianRed;
			this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDelete.Location = new System.Drawing.Point(469, 183);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(132, 33);
			this.btnDelete.TabIndex = 11;
			this.btnDelete.Text = "Delete";
			this.btnDelete.UseVisualStyleBackColor = false;
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click_1);
			// 
			// btnRequest
			// 
			this.btnRequest.BackColor = System.Drawing.Color.Wheat;
			this.btnRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnRequest.Location = new System.Drawing.Point(17, 183);
			this.btnRequest.Name = "btnRequest";
			this.btnRequest.Size = new System.Drawing.Size(130, 33);
			this.btnRequest.TabIndex = 10;
			this.btnRequest.Text = "Submit Request";
			this.btnRequest.UseVisualStyleBackColor = false;
			this.btnRequest.Click += new System.EventHandler(this.btnRequest_Click_1);
			// 
			// cmdLeave
			// 
			this.cmdLeave.FormattingEnabled = true;
			this.cmdLeave.Items.AddRange(new object[] {
            "Annual",
            "Sick",
            "Casual",
            "Unpaid"});
			this.cmdLeave.Location = new System.Drawing.Point(166, 64);
			this.cmdLeave.Name = "cmdLeave";
			this.cmdLeave.Size = new System.Drawing.Size(150, 24);
			this.cmdLeave.TabIndex = 9;
			// 
			// dtpEnd
			// 
			this.dtpEnd.Location = new System.Drawing.Point(439, 100);
			this.dtpEnd.Name = "dtpEnd";
			this.dtpEnd.Size = new System.Drawing.Size(150, 22);
			this.dtpEnd.TabIndex = 8;
			// 
			// dtpStart
			// 
			this.dtpStart.Location = new System.Drawing.Point(166, 100);
			this.dtpStart.Name = "dtpStart";
			this.dtpStart.Size = new System.Drawing.Size(150, 22);
			this.dtpStart.TabIndex = 7;
			// 
			// txtReason
			// 
			this.txtReason.Location = new System.Drawing.Point(166, 136);
			this.txtReason.Name = "txtReason";
			this.txtReason.Size = new System.Drawing.Size(150, 22);
			this.txtReason.TabIndex = 6;
			// 
			// txtEmployee
			// 
			this.txtEmployee.Location = new System.Drawing.Point(166, 25);
			this.txtEmployee.Name = "txtEmployee";
			this.txtEmployee.Size = new System.Drawing.Size(150, 22);
			this.txtEmployee.TabIndex = 5;
			// 
			// lbLeave
			// 
			this.lbLeave.AutoSize = true;
			this.lbLeave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbLeave.Location = new System.Drawing.Point(42, 64);
			this.lbLeave.Name = "lbLeave";
			this.lbLeave.Size = new System.Drawing.Size(95, 20);
			this.lbLeave.TabIndex = 4;
			this.lbLeave.Text = "Leave Type";
			// 
			// lbStart
			// 
			this.lbStart.AutoSize = true;
			this.lbStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbStart.Location = new System.Drawing.Point(42, 102);
			this.lbStart.Name = "lbStart";
			this.lbStart.Size = new System.Drawing.Size(86, 20);
			this.lbStart.TabIndex = 3;
			this.lbStart.Text = "Start Date";
			// 
			// lbReason
			// 
			this.lbReason.AutoSize = true;
			this.lbReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbReason.Location = new System.Drawing.Point(42, 138);
			this.lbReason.Name = "lbReason";
			this.lbReason.Size = new System.Drawing.Size(66, 20);
			this.lbReason.TabIndex = 2;
			this.lbReason.Text = "Reason";
			// 
			// lbEnd
			// 
			this.lbEnd.AutoSize = true;
			this.lbEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbEnd.Location = new System.Drawing.Point(345, 102);
			this.lbEnd.Name = "lbEnd";
			this.lbEnd.Size = new System.Drawing.Size(79, 20);
			this.lbEnd.TabIndex = 1;
			this.lbEnd.Text = "End Date";
			this.lbEnd.Click += new System.EventHandler(this.label2_Click);
			// 
			// dataGridView1
			// 
			this.dataGridView1.AutoGenerateColumns = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.leaveIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.leaveTypeDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.reasonDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
			this.dataGridView1.DataSource = this.leaveRequestsBindingSource;
			this.dataGridView1.Location = new System.Drawing.Point(12, 287);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 51;
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(636, 183);
			this.dataGridView1.TabIndex = 2;
			// 
			// leaveIDDataGridViewTextBoxColumn
			// 
			this.leaveIDDataGridViewTextBoxColumn.DataPropertyName = "LeaveID";
			this.leaveIDDataGridViewTextBoxColumn.HeaderText = "LeaveID";
			this.leaveIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.leaveIDDataGridViewTextBoxColumn.Name = "leaveIDDataGridViewTextBoxColumn";
			this.leaveIDDataGridViewTextBoxColumn.ReadOnly = true;
			this.leaveIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// employeeIDDataGridViewTextBoxColumn
			// 
			this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
			this.employeeIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// leaveTypeDataGridViewTextBoxColumn
			// 
			this.leaveTypeDataGridViewTextBoxColumn.DataPropertyName = "LeaveType";
			this.leaveTypeDataGridViewTextBoxColumn.HeaderText = "LeaveType";
			this.leaveTypeDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.leaveTypeDataGridViewTextBoxColumn.Name = "leaveTypeDataGridViewTextBoxColumn";
			this.leaveTypeDataGridViewTextBoxColumn.Width = 125;
			// 
			// startDateDataGridViewTextBoxColumn
			// 
			this.startDateDataGridViewTextBoxColumn.DataPropertyName = "StartDate";
			this.startDateDataGridViewTextBoxColumn.HeaderText = "StartDate";
			this.startDateDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
			this.startDateDataGridViewTextBoxColumn.Width = 125;
			// 
			// endDateDataGridViewTextBoxColumn
			// 
			this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
			this.endDateDataGridViewTextBoxColumn.HeaderText = "EndDate";
			this.endDateDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
			this.endDateDataGridViewTextBoxColumn.Width = 125;
			// 
			// reasonDataGridViewTextBoxColumn
			// 
			this.reasonDataGridViewTextBoxColumn.DataPropertyName = "Reason";
			this.reasonDataGridViewTextBoxColumn.HeaderText = "Reason";
			this.reasonDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.reasonDataGridViewTextBoxColumn.Name = "reasonDataGridViewTextBoxColumn";
			this.reasonDataGridViewTextBoxColumn.Width = 125;
			// 
			// statusDataGridViewTextBoxColumn
			// 
			this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
			this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
			this.statusDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
			this.statusDataGridViewTextBoxColumn.Width = 125;
			// 
			// leaveRequestsBindingSource
			// 
			this.leaveRequestsBindingSource.DataMember = "LeaveRequests";
			this.leaveRequestsBindingSource.DataSource = this.eMSDBDataSet;
			// 
			// eMSDBDataSet
			// 
			this.eMSDBDataSet.DataSetName = "EMSDBDataSet";
			this.eMSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// leaveRequestsTableAdapter
			// 
			this.leaveRequestsTableAdapter.ClearBeforeFill = true;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(12, 477);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 19;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// LeaveRequest
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(673, 502);
			this.Controls.Add(this.linklbDashboard);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.panelLeave);
			this.Name = "LeaveRequest";
			this.Text = "LeaveRequest";
			this.Load += new System.EventHandler(this.LeaveRequest_Load);
			this.panelLeave.ResumeLayout(false);
			this.panelLeave.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.leaveRequestsBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panelLeave;
		private System.Windows.Forms.Label lbLeave;
		private System.Windows.Forms.Label lbStart;
		private System.Windows.Forms.Label lbReason;
		private System.Windows.Forms.Label lbEnd;
		private System.Windows.Forms.DateTimePicker dtpEnd;
		private System.Windows.Forms.DateTimePicker dtpStart;
		private System.Windows.Forms.TextBox txtReason;
		private System.Windows.Forms.TextBox txtEmployee;
		private System.Windows.Forms.Button btnApprove;
		private System.Windows.Forms.Button btnReject;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnRequest;
		private System.Windows.Forms.ComboBox cmdLeave;
		private System.Windows.Forms.DataGridView dataGridView1;
		private EMSDBDataSet eMSDBDataSet;
		private System.Windows.Forms.BindingSource leaveRequestsBindingSource;
		private EMSDBDataSetTableAdapters.LeaveRequestsTableAdapter leaveRequestsTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn leaveIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn leaveTypeDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn reasonDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}