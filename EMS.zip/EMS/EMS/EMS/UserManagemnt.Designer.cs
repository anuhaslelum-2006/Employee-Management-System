﻿namespace EMS
{
	partial class UserManagemnt
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lbUsername2 = new System.Windows.Forms.Label();
			this.lbPasswordManagement = new System.Windows.Forms.Label();
			this.lbCOnfirmPasswordManagement = new System.Windows.Forms.Label();
			this.lbRole = new System.Windows.Forms.Label();
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.txtConfirm = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.btnAddUser = new System.Windows.Forms.Button();
			this.btnUpdate = new System.Windows.Forms.Button();
			this.btnDelete = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.userIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.passwordHashDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.roleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSet = new EMS.EMSDBDataSet();
			this.usersTableAdapter = new EMS.EMSDBDataSetTableAdapters.UsersTableAdapter();
			this.btnOpen = new System.Windows.Forms.Button();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).BeginInit();
			this.SuspendLayout();
			// 
			// lbUsername2
			// 
			this.lbUsername2.AutoSize = true;
			this.lbUsername2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbUsername2.Location = new System.Drawing.Point(33, 19);
			this.lbUsername2.Name = "lbUsername2";
			this.lbUsername2.Size = new System.Drawing.Size(86, 20);
			this.lbUsername2.TabIndex = 0;
			this.lbUsername2.Text = "Username";
			this.lbUsername2.Click += new System.EventHandler(this.lbUsername2_Click);
			// 
			// lbPasswordManagement
			// 
			this.lbPasswordManagement.AutoSize = true;
			this.lbPasswordManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbPasswordManagement.Location = new System.Drawing.Point(33, 67);
			this.lbPasswordManagement.Name = "lbPasswordManagement";
			this.lbPasswordManagement.Size = new System.Drawing.Size(83, 20);
			this.lbPasswordManagement.TabIndex = 1;
			this.lbPasswordManagement.Text = "Password";
			// 
			// lbCOnfirmPasswordManagement
			// 
			this.lbCOnfirmPasswordManagement.AutoSize = true;
			this.lbCOnfirmPasswordManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbCOnfirmPasswordManagement.Location = new System.Drawing.Point(33, 111);
			this.lbCOnfirmPasswordManagement.Name = "lbCOnfirmPasswordManagement";
			this.lbCOnfirmPasswordManagement.Size = new System.Drawing.Size(147, 20);
			this.lbCOnfirmPasswordManagement.TabIndex = 2;
			this.lbCOnfirmPasswordManagement.Text = "Confirm Password";
			// 
			// lbRole
			// 
			this.lbRole.AutoSize = true;
			this.lbRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbRole.Location = new System.Drawing.Point(33, 158);
			this.lbRole.Name = "lbRole";
			this.lbRole.Size = new System.Drawing.Size(43, 20);
			this.lbRole.TabIndex = 3;
			this.lbRole.Text = "Role";
			// 
			// txtUsername
			// 
			this.txtUsername.Location = new System.Drawing.Point(205, 17);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new System.Drawing.Size(161, 22);
			this.txtUsername.TabIndex = 4;
			// 
			// txtConfirm
			// 
			this.txtConfirm.Location = new System.Drawing.Point(205, 110);
			this.txtConfirm.Name = "txtConfirm";
			this.txtConfirm.Size = new System.Drawing.Size(161, 22);
			this.txtConfirm.TabIndex = 5;
			// 
			// txtPassword
			// 
			this.txtPassword.Location = new System.Drawing.Point(205, 65);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(161, 22);
			this.txtPassword.TabIndex = 6;
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "Admin",
            "User"});
			this.comboBox1.Location = new System.Drawing.Point(205, 154);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(161, 24);
			this.comboBox1.TabIndex = 7;
			// 
			// btnAddUser
			// 
			this.btnAddUser.BackColor = System.Drawing.Color.Chartreuse;
			this.btnAddUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddUser.Location = new System.Drawing.Point(22, 209);
			this.btnAddUser.Name = "btnAddUser";
			this.btnAddUser.Size = new System.Drawing.Size(99, 32);
			this.btnAddUser.TabIndex = 8;
			this.btnAddUser.Text = "Add User";
			this.btnAddUser.UseVisualStyleBackColor = false;
			// 
			// btnUpdate
			// 
			this.btnUpdate.BackColor = System.Drawing.Color.Aqua;
			this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnUpdate.Location = new System.Drawing.Point(136, 209);
			this.btnUpdate.Name = "btnUpdate";
			this.btnUpdate.Size = new System.Drawing.Size(99, 32);
			this.btnUpdate.TabIndex = 9;
			this.btnUpdate.Text = "Update";
			this.btnUpdate.UseVisualStyleBackColor = false;
			// 
			// btnDelete
			// 
			this.btnDelete.BackColor = System.Drawing.Color.Tomato;
			this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDelete.Location = new System.Drawing.Point(257, 209);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(99, 32);
			this.btnDelete.TabIndex = 10;
			this.btnDelete.Text = "Delete";
			this.btnDelete.UseVisualStyleBackColor = false;
			// 
			// btnClear
			// 
			this.btnClear.BackColor = System.Drawing.Color.DarkGray;
			this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClear.Location = new System.Drawing.Point(371, 209);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(99, 32);
			this.btnClear.TabIndex = 11;
			this.btnClear.Text = "Clear";
			this.btnClear.UseVisualStyleBackColor = false;
			// 
			// dataGridView1
			// 
			this.dataGridView1.AutoGenerateColumns = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.userIDDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.passwordHashDataGridViewTextBoxColumn,
            this.roleDataGridViewTextBoxColumn});
			this.dataGridView1.DataSource = this.usersBindingSource;
			this.dataGridView1.Location = new System.Drawing.Point(22, 258);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 51;
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(448, 162);
			this.dataGridView1.TabIndex = 12;
			// 
			// userIDDataGridViewTextBoxColumn
			// 
			this.userIDDataGridViewTextBoxColumn.DataPropertyName = "UserID";
			this.userIDDataGridViewTextBoxColumn.HeaderText = "UserID";
			this.userIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.userIDDataGridViewTextBoxColumn.Name = "userIDDataGridViewTextBoxColumn";
			this.userIDDataGridViewTextBoxColumn.ReadOnly = true;
			this.userIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// usernameDataGridViewTextBoxColumn
			// 
			this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
			this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
			this.usernameDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
			this.usernameDataGridViewTextBoxColumn.Width = 125;
			// 
			// passwordHashDataGridViewTextBoxColumn
			// 
			this.passwordHashDataGridViewTextBoxColumn.DataPropertyName = "PasswordHash";
			this.passwordHashDataGridViewTextBoxColumn.HeaderText = "PasswordHash";
			this.passwordHashDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.passwordHashDataGridViewTextBoxColumn.Name = "passwordHashDataGridViewTextBoxColumn";
			this.passwordHashDataGridViewTextBoxColumn.Width = 125;
			// 
			// roleDataGridViewTextBoxColumn
			// 
			this.roleDataGridViewTextBoxColumn.DataPropertyName = "Role";
			this.roleDataGridViewTextBoxColumn.HeaderText = "Role";
			this.roleDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.roleDataGridViewTextBoxColumn.Name = "roleDataGridViewTextBoxColumn";
			this.roleDataGridViewTextBoxColumn.Width = 125;
			// 
			// usersBindingSource
			// 
			this.usersBindingSource.DataMember = "Users";
			this.usersBindingSource.DataSource = this.eMSDBDataSet;
			// 
			// eMSDBDataSet
			// 
			this.eMSDBDataSet.DataSetName = "EMSDBDataSet";
			this.eMSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// usersTableAdapter
			// 
			this.usersTableAdapter.ClearBeforeFill = true;
			// 
			// btnOpen
			// 
			this.btnOpen.BackColor = System.Drawing.Color.Yellow;
			this.btnOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnOpen.Location = new System.Drawing.Point(279, 437);
			this.btnOpen.Name = "btnOpen";
			this.btnOpen.Size = new System.Drawing.Size(191, 34);
			this.btnOpen.TabIndex = 13;
			this.btnOpen.Text = "Open Password Change";
			this.btnOpen.UseVisualStyleBackColor = false;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(34, 455);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 19;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// UserManagemnt
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(503, 487);
			this.Controls.Add(this.linklbDashboard);
			this.Controls.Add(this.btnOpen);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnDelete);
			this.Controls.Add(this.btnUpdate);
			this.Controls.Add(this.btnAddUser);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtConfirm);
			this.Controls.Add(this.txtUsername);
			this.Controls.Add(this.lbRole);
			this.Controls.Add(this.lbCOnfirmPasswordManagement);
			this.Controls.Add(this.lbPasswordManagement);
			this.Controls.Add(this.lbUsername2);
			this.Name = "UserManagemnt";
			this.Text = "UserManagemnt";
			this.Load += new System.EventHandler(this.UserManagemnt_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lbUsername2;
		private System.Windows.Forms.Label lbPasswordManagement;
		private System.Windows.Forms.Label lbCOnfirmPasswordManagement;
		private System.Windows.Forms.Label lbRole;
		private System.Windows.Forms.TextBox txtUsername;
		private System.Windows.Forms.TextBox txtConfirm;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Button btnAddUser;
		private System.Windows.Forms.Button btnUpdate;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.DataGridView dataGridView1;
		private EMSDBDataSet eMSDBDataSet;
		private System.Windows.Forms.BindingSource usersBindingSource;
		private EMSDBDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn passwordHashDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn roleDataGridViewTextBoxColumn;
		private System.Windows.Forms.Button btnOpen;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}