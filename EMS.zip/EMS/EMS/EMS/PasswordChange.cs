﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace EMS
{
	public partial class PasswordChange : Form
	{
		private EMSDBDataSetTableAdapters.UsersTableAdapter userAdapter;

		public PasswordChange()
		{
			InitializeComponent();

			this.AutoScroll = true;

			this.btnSaveChanges.Click += btnSaveChanges_Click;
			this.Load += PasswordChange_Load;
			this.linklbDashboard.Click += linklbDashboard_Click; 

			userAdapter = new EMSDBDataSetTableAdapters.UsersTableAdapter();
		}

		private void PasswordChange_Load(object sender, EventArgs e) { }

		private void btnSaveChanges_Click(object sender, EventArgs e)
		{
			if (Session.UserID == 0)
			{
				MessageBox.Show("You are not logged in. Please log in again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				this.Close();
				return;
			}

			string oldPassword = txtOld.Text;
			string newPassword = txtNew.Text;
			string confirmPassword = txtConfirm.Text;

			if (string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword))
			{
				MessageBox.Show("Please fill in all password fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (newPassword != confirmPassword)
			{
				MessageBox.Show("New password and confirmation do not match.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (oldPassword == newPassword)
			{
				MessageBox.Show("New password must be different from the old password.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				var users = userAdapter.GetData();
				var currentUser = users.FirstOrDefault(u => u.UserID == Session.UserID);

				if (currentUser == null)
				{
					MessageBox.Show("User not found. Please log in again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					this.Close();
					return;
				}

				if (currentUser.PasswordHash != oldPassword)
				{
					MessageBox.Show("Old password is incorrect.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}

				userAdapter.Update(
					currentUser.Username,
					newPassword,
					currentUser.Role,
					currentUser.UserID,
					currentUser.Username,
					currentUser.PasswordHash,
					currentUser.Role
				);

				MessageBox.Show("Password changed successfully. Please log in again with your new password.",
								"Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

				Session.UserID = 0;
				Session.Username = null;
				Session.Role = null;

				this.Close();
				Application.Restart();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error changing password: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void linklbDashboard_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}