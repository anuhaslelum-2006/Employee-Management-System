﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace EMS
{
	public partial class UserManagemnt : Form
	{
		private EMSDBDataSetTableAdapters.UsersTableAdapter userAdapter;
		private EMSDBDataSet.UsersDataTable userTable;

		public UserManagemnt()
		{
			InitializeComponent();
			this.AutoScroll = true;

			this.btnAddUser.Click += btnAddUser_Click;
			this.btnUpdate.Click += btnUpdate_Click;
			this.btnDelete.Click += btnDelete_Click;
			this.btnClear.Click += btnClear_Click;
			this.btnOpen.Click += btnOpen_Click;
			this.dataGridView1.CellClick += dataGridView1_CellClick;
			this.linklbDashboard.Click += linklbDashboard_Click;

			userAdapter = new EMSDBDataSetTableAdapters.UsersTableAdapter();

			
			if (Session.Role != "Admin")
			{
				MessageBox.Show("You do not have permission to access User Management.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.Close();
				return;
			}
		}

		private void UserManagemnt_Load(object sender, EventArgs e) => LoadUsers();

		private void lbUsername2_Click(object sender, EventArgs e) { }

		private void LoadUsers()
		{
			try
			{
				userTable = userAdapter.GetData();
				usersBindingSource.DataSource = userTable;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading users: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnAddUser_Click(object sender, EventArgs e)
		{
			string username = txtUsername.Text.Trim();
			string password = txtPassword.Text;
			string confirm = txtConfirm.Text;

			if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
			{
				MessageBox.Show("Username and password are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (password != confirm)
			{
				MessageBox.Show("Passwords do not match.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (userTable.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
			{
				MessageBox.Show("Username already exists. Please choose a different username.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string role = comboBox1.SelectedItem?.ToString();
			if (string.IsNullOrEmpty(role)) role = "User";

			try
			{
				userAdapter.Insert(username, password, role);
				LoadUsers();
				ClearFields();
				MessageBox.Show("User added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error adding user: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a user to update.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int userID = (int)dataGridView1.CurrentRow.Cells["userIDDataGridViewTextBoxColumn"].Value;
			string oldUsername = dataGridView1.CurrentRow.Cells["usernameDataGridViewTextBoxColumn"].Value.ToString();
			string oldPassword = dataGridView1.CurrentRow.Cells["passwordHashDataGridViewTextBoxColumn"].Value.ToString();
			string oldRole = dataGridView1.CurrentRow.Cells["roleDataGridViewTextBoxColumn"].Value.ToString();

			string newUsername = txtUsername.Text.Trim();
			string newPassword = txtPassword.Text;
			string confirm = txtConfirm.Text;
			string newRole = comboBox1.SelectedItem?.ToString();

			if (string.IsNullOrEmpty(newUsername))
			{
				MessageBox.Show("Username is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (!string.IsNullOrEmpty(newPassword) && newPassword != confirm)
			{
				MessageBox.Show("Passwords do not match.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string finalPassword = string.IsNullOrEmpty(newPassword) ? oldPassword : newPassword;
			if (string.IsNullOrEmpty(newRole)) newRole = oldRole;

			try
			{
				userAdapter.Update(newUsername, finalPassword, newRole, userID, oldUsername, oldPassword, oldRole);
				LoadUsers();
				ClearFields();
				MessageBox.Show("User updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error updating user: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a user to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int userID = (int)dataGridView1.CurrentRow.Cells["userIDDataGridViewTextBoxColumn"].Value;
			if (Session.IsLoggedIn && userID == Session.UserID)
			{
				MessageBox.Show("You cannot delete your own account.", "Permission Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (MessageBox.Show("Are you sure you want to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				try
				{
					userAdapter.Delete(userID, "", "", "");
					LoadUsers();
					ClearFields();
					MessageBox.Show("User deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error deleting user: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		private void btnClear_Click(object sender, EventArgs e) => ClearFields();

		private void btnOpen_Click(object sender, EventArgs e)
		{
			PasswordChange pc = new PasswordChange();
			pc.ShowDialog();
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
				txtUsername.Text = row.Cells["usernameDataGridViewTextBoxColumn"].Value.ToString();
				txtPassword.Text = row.Cells["passwordHashDataGridViewTextBoxColumn"].Value.ToString();
				txtConfirm.Text = row.Cells["passwordHashDataGridViewTextBoxColumn"].Value.ToString();
				comboBox1.SelectedItem = row.Cells["roleDataGridViewTextBoxColumn"].Value.ToString();
			}
		}

		private void ClearFields()
		{
			txtUsername.Clear();
			txtPassword.Clear();
			txtConfirm.Clear();
			comboBox1.SelectedIndex = -1;
		}

		private void linklbDashboard_Click(object sender, EventArgs e) => this.Close();
	}
}