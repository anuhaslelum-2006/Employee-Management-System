﻿using System;

namespace EMS
{
	public static class Session
	{
		public static int UserID { get; set; }
		public static string Username { get; set; }
		public static string Role { get; set; }
		public static bool IsLoggedIn => UserID > 0;
	}
}