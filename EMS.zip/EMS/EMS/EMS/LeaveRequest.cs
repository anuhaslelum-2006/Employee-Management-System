﻿using System;
using System.Data;
using System.Windows.Forms;

namespace EMS
{
	public partial class LeaveRequest : Form
	{
		private EMSDBDataSetTableAdapters.LeaveRequestsTableAdapter leaveAdapter;
		private EMSDBDataSetTableAdapters.EmployeesTableAdapter empAdapter;

		public LeaveRequest()
		{
			InitializeComponent();
			this.AutoScroll = true;

			
			this.btnRequest.Click += btnRequest_Click;
			this.btnApprove.Click += btnApprove_Click;
			this.btnReject.Click += btnReject_Click;
			this.btnDelete.Click += btnDelete_Click;
			this.linklbDashboard.Click += linklbDashboard_Click;

			leaveAdapter = new EMSDBDataSetTableAdapters.LeaveRequestsTableAdapter();
			empAdapter = new EMSDBDataSetTableAdapters.EmployeesTableAdapter();

			
			if (Session.Role != "Admin")
			{
				btnApprove.Enabled = false;
				btnReject.Enabled = false;
				btnDelete.Enabled = false;
			}
		}

		// 
		private void LeaveRequest_Load(object sender, EventArgs e) => LoadLeaveRequests();

		private void label2_Click(object sender, EventArgs e) { }

		// 
		private void btnApprove_Click_1(object sender, EventArgs e) => btnApprove_Click(sender, e);
		private void btnReject_Click_1(object sender, EventArgs e) => btnReject_Click(sender, e);
		private void btnDelete_Click_1(object sender, EventArgs e) => btnDelete_Click(sender, e);
		private void btnRequest_Click_1(object sender, EventArgs e) => btnRequest_Click(sender, e);

		// 
		private void LoadLeaveRequests()
		{
			try
			{
				this.leaveRequestsTableAdapter.Fill(this.eMSDBDataSet.LeaveRequests);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading leave requests: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 
		private void btnRequest_Click(object sender, EventArgs e)
		{
			if (!int.TryParse(txtEmployee.Text, out int empID))
			{
				MessageBox.Show("Please enter a valid numeric Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				var empTable = empAdapter.GetData();
				if (empTable.FindByEmployeeID(empID) == null)
				{
					MessageBox.Show("Employee ID not found. Please enter a valid Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error verifying employee: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			string leaveType = cmdLeave.SelectedItem?.ToString();
			if (string.IsNullOrEmpty(leaveType))
			{
				MessageBox.Show("Please select a leave type.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dtpStart.Value.Date > dtpEnd.Value.Date)
			{
				MessageBox.Show("End date must be on or after the start date.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string reason = txtReason.Text.Trim();

			try
			{
				leaveAdapter.Insert(empID, leaveType, dtpStart.Value.Date, dtpEnd.Value.Date,
									string.IsNullOrEmpty(reason) ? null : reason, "Pending");
				LoadLeaveRequests();
				ClearFields();
				MessageBox.Show("Leave request submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error submitting request: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 
		private void btnApprove_Click(object sender, EventArgs e) => UpdateLeaveStatus("Approved");
		private void btnReject_Click(object sender, EventArgs e) => UpdateLeaveStatus("Rejected");

		private void UpdateLeaveStatus(string newStatus)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can approve or reject leave requests.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a leave request to " + newStatus.ToLower() + ".", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int leaveID = (int)dataGridView1.CurrentRow.Cells["leaveIDDataGridViewTextBoxColumn"].Value;
			int empID = (int)dataGridView1.CurrentRow.Cells["employeeIDDataGridViewTextBoxColumn"].Value;
			string leaveType = dataGridView1.CurrentRow.Cells["leaveTypeDataGridViewTextBoxColumn"].Value.ToString();
			DateTime startDate = (DateTime)dataGridView1.CurrentRow.Cells["startDateDataGridViewTextBoxColumn"].Value;
			DateTime endDate = (DateTime)dataGridView1.CurrentRow.Cells["endDateDataGridViewTextBoxColumn"].Value;
			string reason = dataGridView1.CurrentRow.Cells["reasonDataGridViewTextBoxColumn"].Value?.ToString();
			string oldStatus = dataGridView1.CurrentRow.Cells["statusDataGridViewTextBoxColumn"].Value.ToString();

			try
			{
				leaveAdapter.Update(empID, leaveType, startDate, endDate, reason, newStatus,
									leaveID, empID, leaveType, startDate, endDate, reason, oldStatus);
				LoadLeaveRequests();
				MessageBox.Show($"Leave request {newStatus}.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error updating status: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 
		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can delete leave requests.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a leave request to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (MessageBox.Show("Are you sure you want to delete this leave request?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				int leaveID = (int)dataGridView1.CurrentRow.Cells["leaveIDDataGridViewTextBoxColumn"].Value;
				try
				{
					leaveAdapter.Delete(leaveID, 0, "", DateTime.Now, DateTime.Now, "", "");
					LoadLeaveRequests();
					ClearFields();
					MessageBox.Show("Leave request deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error deleting request: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		// 
		private void ClearFields()
		{
			txtEmployee.Clear();
			txtReason.Clear();
			cmdLeave.SelectedIndex = -1;
			dtpStart.Value = DateTime.Now;
			dtpEnd.Value = DateTime.Now;
		}

		// 
		private void linklbDashboard_Click(object sender, EventArgs e) => this.Close();
	}
}