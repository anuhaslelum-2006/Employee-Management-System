﻿namespace EMS
{
	partial class Salary
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lbMonth = new System.Windows.Forms.Label();
			this.dtpMonth = new System.Windows.Forms.DateTimePicker();
			this.btnProcess = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.salaryIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.monthYearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.basicSalaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.totalDaysDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.presentDaysDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.leaveDaysDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.deductionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.bonusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.netSalaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.generatedDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.salaryBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSet = new EMS.EMSDBDataSet();
			this.salaryTableAdapter = new EMS.EMSDBDataSetTableAdapters.SalaryTableAdapter();
			this.btnPayslip = new System.Windows.Forms.Button();
			this.btnDeleteSalary = new System.Windows.Forms.Button();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.salaryBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).BeginInit();
			this.SuspendLayout();
			// 
			// lbMonth
			// 
			this.lbMonth.AutoSize = true;
			this.lbMonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbMonth.Location = new System.Drawing.Point(23, 40);
			this.lbMonth.Name = "lbMonth";
			this.lbMonth.Size = new System.Drawing.Size(107, 20);
			this.lbMonth.TabIndex = 0;
			this.lbMonth.Text = "Select Month";
			// 
			// dtpMonth
			// 
			this.dtpMonth.Location = new System.Drawing.Point(158, 38);
			this.dtpMonth.Name = "dtpMonth";
			this.dtpMonth.Size = new System.Drawing.Size(150, 22);
			this.dtpMonth.TabIndex = 1;
			// 
			// btnProcess
			// 
			this.btnProcess.BackColor = System.Drawing.Color.Gold;
			this.btnProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnProcess.Location = new System.Drawing.Point(326, 28);
			this.btnProcess.Name = "btnProcess";
			this.btnProcess.Size = new System.Drawing.Size(184, 32);
			this.btnProcess.TabIndex = 2;
			this.btnProcess.Text = "Process Salaries";
			this.btnProcess.UseVisualStyleBackColor = false;
			// 
			// dataGridView1
			// 
			this.dataGridView1.AutoGenerateColumns = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.salaryIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.monthYearDataGridViewTextBoxColumn,
            this.basicSalaryDataGridViewTextBoxColumn,
            this.totalDaysDataGridViewTextBoxColumn,
            this.presentDaysDataGridViewTextBoxColumn,
            this.leaveDaysDataGridViewTextBoxColumn,
            this.deductionsDataGridViewTextBoxColumn,
            this.bonusDataGridViewTextBoxColumn,
            this.netSalaryDataGridViewTextBoxColumn,
            this.generatedDateDataGridViewTextBoxColumn});
			this.dataGridView1.DataSource = this.salaryBindingSource;
			this.dataGridView1.Location = new System.Drawing.Point(12, 97);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 51;
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(498, 246);
			this.dataGridView1.TabIndex = 3;
			// 
			// salaryIDDataGridViewTextBoxColumn
			// 
			this.salaryIDDataGridViewTextBoxColumn.DataPropertyName = "SalaryID";
			this.salaryIDDataGridViewTextBoxColumn.HeaderText = "SalaryID";
			this.salaryIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.salaryIDDataGridViewTextBoxColumn.Name = "salaryIDDataGridViewTextBoxColumn";
			this.salaryIDDataGridViewTextBoxColumn.ReadOnly = true;
			this.salaryIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// employeeIDDataGridViewTextBoxColumn
			// 
			this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
			this.employeeIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// monthYearDataGridViewTextBoxColumn
			// 
			this.monthYearDataGridViewTextBoxColumn.DataPropertyName = "MonthYear";
			this.monthYearDataGridViewTextBoxColumn.HeaderText = "MonthYear";
			this.monthYearDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.monthYearDataGridViewTextBoxColumn.Name = "monthYearDataGridViewTextBoxColumn";
			this.monthYearDataGridViewTextBoxColumn.Width = 125;
			// 
			// basicSalaryDataGridViewTextBoxColumn
			// 
			this.basicSalaryDataGridViewTextBoxColumn.DataPropertyName = "BasicSalary";
			this.basicSalaryDataGridViewTextBoxColumn.HeaderText = "BasicSalary";
			this.basicSalaryDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.basicSalaryDataGridViewTextBoxColumn.Name = "basicSalaryDataGridViewTextBoxColumn";
			this.basicSalaryDataGridViewTextBoxColumn.Width = 125;
			// 
			// totalDaysDataGridViewTextBoxColumn
			// 
			this.totalDaysDataGridViewTextBoxColumn.DataPropertyName = "TotalDays";
			this.totalDaysDataGridViewTextBoxColumn.HeaderText = "TotalDays";
			this.totalDaysDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.totalDaysDataGridViewTextBoxColumn.Name = "totalDaysDataGridViewTextBoxColumn";
			this.totalDaysDataGridViewTextBoxColumn.Width = 125;
			// 
			// presentDaysDataGridViewTextBoxColumn
			// 
			this.presentDaysDataGridViewTextBoxColumn.DataPropertyName = "PresentDays";
			this.presentDaysDataGridViewTextBoxColumn.HeaderText = "PresentDays";
			this.presentDaysDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.presentDaysDataGridViewTextBoxColumn.Name = "presentDaysDataGridViewTextBoxColumn";
			this.presentDaysDataGridViewTextBoxColumn.Width = 125;
			// 
			// leaveDaysDataGridViewTextBoxColumn
			// 
			this.leaveDaysDataGridViewTextBoxColumn.DataPropertyName = "LeaveDays";
			this.leaveDaysDataGridViewTextBoxColumn.HeaderText = "LeaveDays";
			this.leaveDaysDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.leaveDaysDataGridViewTextBoxColumn.Name = "leaveDaysDataGridViewTextBoxColumn";
			this.leaveDaysDataGridViewTextBoxColumn.Width = 125;
			// 
			// deductionsDataGridViewTextBoxColumn
			// 
			this.deductionsDataGridViewTextBoxColumn.DataPropertyName = "Deductions";
			this.deductionsDataGridViewTextBoxColumn.HeaderText = "Deductions";
			this.deductionsDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.deductionsDataGridViewTextBoxColumn.Name = "deductionsDataGridViewTextBoxColumn";
			this.deductionsDataGridViewTextBoxColumn.Width = 125;
			// 
			// bonusDataGridViewTextBoxColumn
			// 
			this.bonusDataGridViewTextBoxColumn.DataPropertyName = "Bonus";
			this.bonusDataGridViewTextBoxColumn.HeaderText = "Bonus";
			this.bonusDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.bonusDataGridViewTextBoxColumn.Name = "bonusDataGridViewTextBoxColumn";
			this.bonusDataGridViewTextBoxColumn.Width = 125;
			// 
			// netSalaryDataGridViewTextBoxColumn
			// 
			this.netSalaryDataGridViewTextBoxColumn.DataPropertyName = "NetSalary";
			this.netSalaryDataGridViewTextBoxColumn.HeaderText = "NetSalary";
			this.netSalaryDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.netSalaryDataGridViewTextBoxColumn.Name = "netSalaryDataGridViewTextBoxColumn";
			this.netSalaryDataGridViewTextBoxColumn.Width = 125;
			// 
			// generatedDateDataGridViewTextBoxColumn
			// 
			this.generatedDateDataGridViewTextBoxColumn.DataPropertyName = "GeneratedDate";
			this.generatedDateDataGridViewTextBoxColumn.HeaderText = "GeneratedDate";
			this.generatedDateDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.generatedDateDataGridViewTextBoxColumn.Name = "generatedDateDataGridViewTextBoxColumn";
			this.generatedDateDataGridViewTextBoxColumn.Width = 125;
			// 
			// salaryBindingSource
			// 
			this.salaryBindingSource.DataMember = "Salary";
			this.salaryBindingSource.DataSource = this.eMSDBDataSet;
			// 
			// eMSDBDataSet
			// 
			this.eMSDBDataSet.DataSetName = "EMSDBDataSet";
			this.eMSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// salaryTableAdapter
			// 
			this.salaryTableAdapter.ClearBeforeFill = true;
			// 
			// btnPayslip
			// 
			this.btnPayslip.BackColor = System.Drawing.Color.YellowGreen;
			this.btnPayslip.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPayslip.Location = new System.Drawing.Point(12, 362);
			this.btnPayslip.Name = "btnPayslip";
			this.btnPayslip.Size = new System.Drawing.Size(192, 35);
			this.btnPayslip.TabIndex = 4;
			this.btnPayslip.Text = "VIew PaySlip";
			this.btnPayslip.UseVisualStyleBackColor = false;
			// 
			// btnDeleteSalary
			// 
			this.btnDeleteSalary.BackColor = System.Drawing.Color.Brown;
			this.btnDeleteSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDeleteSalary.Location = new System.Drawing.Point(314, 362);
			this.btnDeleteSalary.Name = "btnDeleteSalary";
			this.btnDeleteSalary.Size = new System.Drawing.Size(192, 35);
			this.btnDeleteSalary.TabIndex = 5;
			this.btnDeleteSalary.Text = "Delete Salary Record";
			this.btnDeleteSalary.UseVisualStyleBackColor = false;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(9, 413);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 19;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// Salary
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(546, 438);
			this.Controls.Add(this.linklbDashboard);
			this.Controls.Add(this.btnDeleteSalary);
			this.Controls.Add(this.btnPayslip);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.btnProcess);
			this.Controls.Add(this.dtpMonth);
			this.Controls.Add(this.lbMonth);
			this.Name = "Salary";
			this.Text = "Salary";
			this.Load += new System.EventHandler(this.Salary_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.salaryBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lbMonth;
		private System.Windows.Forms.DateTimePicker dtpMonth;
		private System.Windows.Forms.Button btnProcess;
		private System.Windows.Forms.DataGridView dataGridView1;
		private EMSDBDataSet eMSDBDataSet;
		private System.Windows.Forms.BindingSource salaryBindingSource;
		private EMSDBDataSetTableAdapters.SalaryTableAdapter salaryTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn salaryIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn monthYearDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn basicSalaryDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn totalDaysDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn presentDaysDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn leaveDaysDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn deductionsDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn bonusDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn netSalaryDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn generatedDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.Button btnPayslip;
		private System.Windows.Forms.Button btnDeleteSalary;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}