﻿using System;
using System.Data;
using System.Windows.Forms;

namespace EMS
{
	public partial class Attendance : Form
	{
		private EMSDBDataSetTableAdapters.AttendanceTableAdapter attAdapter;
		private EMSDBDataSetTableAdapters.EmployeesTableAdapter empAdapter;

		public Attendance()
		{
			InitializeComponent();
			this.AutoScroll = true;

			
			this.btnMark.Click += btnMark_Click;
			this.btnSelected.Click += btnSelected_Click;
			this.linklbDashboard.Click += linklbDashboard_Click;

			attAdapter = new EMSDBDataSetTableAdapters.AttendanceTableAdapter();
			empAdapter = new EMSDBDataSetTableAdapters.EmployeesTableAdapter();

			
			if (Session.Role != "Admin")
			{
				btnSelected.Enabled = false;
				
			}
		}

		
		private void Attendance_Load(object sender, EventArgs e) => LoadAttendance();

		
		private void LoadAttendance()
		{
			try
			{
				this.attendanceTableAdapter.Fill(this.eMSDBDataSet.Attendance);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading attendance data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnMark_Click(object sender, EventArgs e)
		{
			if (!int.TryParse(txtEmployee.Text, out int empID))
			{
				MessageBox.Show("Please enter a valid numeric Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				var empTable = empAdapter.GetData();
				if (empTable.FindByEmployeeID(empID) == null)
				{
					MessageBox.Show("Employee ID not found. Please enter a valid Employee ID.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error verifying employee: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			string status = cmdStatus.SelectedItem?.ToString();
			if (string.IsNullOrEmpty(status))
			{
				MessageBox.Show("Please select a status (Present / Absent).", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			DateTime attDate = dtpDateAttendance.Value.Date;
			string remarks = txtRemarks.Text.Trim();

			try
			{
				attAdapter.Insert(empID, attDate, status, string.IsNullOrEmpty(remarks) ? null : remarks);
				LoadAttendance();
				ClearFields();
				MessageBox.Show("Attendance marked successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				if (ex.Message.Contains("UNIQUE") || ex.Message.Contains("duplicate"))
					MessageBox.Show("Attendance for this employee on the selected date already exists.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				else
					MessageBox.Show("Error marking attendance: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		
		private void btnSelected_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can delete attendance records.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dgvAttendance.CurrentRow == null)
			{
				MessageBox.Show("Please select an attendance record to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (MessageBox.Show("Are you sure you want to delete the selected attendance record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				int attID = (int)dgvAttendance.CurrentRow.Cells["attendanceIDDataGridViewTextBoxColumn"].Value;
				try
				{
					attAdapter.Delete(attID, 0, DateTime.Now, "", "");
					LoadAttendance();
					ClearFields();
					MessageBox.Show("Attendance record deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error deleting record: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		
		private void ClearFields()
		{
			txtEmployee.Clear();
			txtRemarks.Clear();
			cmdStatus.SelectedIndex = -1;
			dtpDateAttendance.Value = DateTime.Now;
		}

		
		private void linklbDashboard_Click(object sender, EventArgs e) => this.Close();
	}
}