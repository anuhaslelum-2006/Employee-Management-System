﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace EMS
{
	public partial class Salary : Form
	{
		private EMSDBDataSetTableAdapters.SalaryTableAdapter salaryAdapter;
		private EMSDBDataSetTableAdapters.EmployeesTableAdapter empAdapter;
		private EMSDBDataSetTableAdapters.AttendanceTableAdapter attAdapter;

		public Salary()
		{
			InitializeComponent();
			this.AutoScroll = true;

			this.btnProcess.Click += btnProcess_Click;
			this.btnPayslip.Click += btnPayslip_Click;
			this.btnDeleteSalary.Click += btnDeleteSalary_Click;
			this.linklbDashboard.Click += linklbDashboard_Click;

			salaryAdapter = new EMSDBDataSetTableAdapters.SalaryTableAdapter();
			empAdapter = new EMSDBDataSetTableAdapters.EmployeesTableAdapter();
			attAdapter = new EMSDBDataSetTableAdapters.AttendanceTableAdapter();

			if (Session.Role != "Admin")
			{
				btnProcess.Enabled = false;
				btnDeleteSalary.Enabled = false;
			}
		}

		private void Salary_Load(object sender, EventArgs e) => LoadSalaries();

		private void LoadSalaries()
		{
			try
			{
				this.salaryTableAdapter.Fill(this.eMSDBDataSet.Salary);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error loading salary data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnProcess_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can process salaries.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			string monthYear = dtpMonth.Value.ToString("yyyy-MM");
			var employees = empAdapter.GetData();

			int processedCount = 0;
			int skippedCount = 0;

			foreach (var emp in employees)
			{
				var existing = eMSDBDataSet.Salary.FirstOrDefault(s => s.EmployeeID == emp.EmployeeID && s.MonthYear == monthYear);
				if (existing != null)
				{
					skippedCount++;
					continue;
				}

				var attendance = attAdapter.GetData().Where(a => a.EmployeeID == emp.EmployeeID &&
																 a.AttendanceDate.Year == dtpMonth.Value.Year &&
																 a.AttendanceDate.Month == dtpMonth.Value.Month);
				int totalDays = DateTime.DaysInMonth(dtpMonth.Value.Year, dtpMonth.Value.Month);
				int presentDays = attendance.Count(a => a.Status == "Present");
				int halfDays = attendance.Count(a => a.Status == "HalfDay");
				presentDays += halfDays;
				int leaveDays = attendance.Count(a => a.Status == "Absent" || a.Status == "Leave");

				decimal basic = emp.BasicSalary;
				decimal perDay = basic / totalDays;
				decimal deductions = perDay * leaveDays;
				decimal bonus = 0;
				decimal net = basic - deductions + bonus;

				try
				{
					salaryAdapter.Insert(emp.EmployeeID, monthYear, basic, totalDays, presentDays, leaveDays, deductions, bonus, net, DateTime.Now);
					processedCount++;
				}
				catch (Exception ex)
				{
					MessageBox.Show($"Error processing Employee ID {emp.EmployeeID}: {ex.Message}", "Processing Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}

			LoadSalaries();
			MessageBox.Show($"Salary processing completed.\nProcessed: {processedCount}\nAlready existed (skipped): {skippedCount}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void btnPayslip_Click(object sender, EventArgs e)
		{
			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a salary record to view payslip.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			int empID = (int)dataGridView1.CurrentRow.Cells["employeeIDDataGridViewTextBoxColumn"].Value;
			string monthYear = dataGridView1.CurrentRow.Cells["monthYearDataGridViewTextBoxColumn"].Value.ToString();
			decimal basic = (decimal)dataGridView1.CurrentRow.Cells["basicSalaryDataGridViewTextBoxColumn"].Value;
			int totalDays = dataGridView1.CurrentRow.Cells["totalDaysDataGridViewTextBoxColumn"].Value == DBNull.Value ? 0 : (int)dataGridView1.CurrentRow.Cells["totalDaysDataGridViewTextBoxColumn"].Value;
			int presentDays = dataGridView1.CurrentRow.Cells["presentDaysDataGridViewTextBoxColumn"].Value == DBNull.Value ? 0 : (int)dataGridView1.CurrentRow.Cells["presentDaysDataGridViewTextBoxColumn"].Value;
			int leaveDays = dataGridView1.CurrentRow.Cells["leaveDaysDataGridViewTextBoxColumn"].Value == DBNull.Value ? 0 : (int)dataGridView1.CurrentRow.Cells["leaveDaysDataGridViewTextBoxColumn"].Value;
			decimal deductions = dataGridView1.CurrentRow.Cells["deductionsDataGridViewTextBoxColumn"].Value == DBNull.Value ? 0 : (decimal)dataGridView1.CurrentRow.Cells["deductionsDataGridViewTextBoxColumn"].Value;
			decimal bonus = dataGridView1.CurrentRow.Cells["bonusDataGridViewTextBoxColumn"].Value == DBNull.Value ? 0 : (decimal)dataGridView1.CurrentRow.Cells["bonusDataGridViewTextBoxColumn"].Value;
			decimal net = (decimal)dataGridView1.CurrentRow.Cells["netSalaryDataGridViewTextBoxColumn"].Value;

			string empName = "Unknown";
			try
			{
				var emp = empAdapter.GetData().FindByEmployeeID(empID);
				if (emp != null) empName = $"{emp.FirstName} {emp.LastName}";
			}
			catch { }

			string payslip = $"================================\n" +
							 $"          PAYSLIP\n" +
							 $"================================\n" +
							 $"Employee: {empName} (ID: {empID})\n" +
							 $"Month: {monthYear}\n" +
							 $"--------------------------------\n" +
							 $"Basic Salary:     {basic:C}\n" +
							 $"Total Days:       {totalDays}\n" +
							 $"Present Days:     {presentDays}\n" +
							 $"Leave Days:       {leaveDays}\n" +
							 $"Deductions:      -{deductions:C}\n" +
							 $"Bonus:            +{bonus:C}\n" +
							 $"--------------------------------\n" +
							 $"NET SALARY:       {net:C}\n" +
							 $"================================\n" +
							 $"Generated on: {DateTime.Now:d}";

			MessageBox.Show(payslip, "Payslip", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void btnDeleteSalary_Click(object sender, EventArgs e)
		{
			if (Session.Role != "Admin")
			{
				MessageBox.Show("Only administrators can delete salary records.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (dataGridView1.CurrentRow == null)
			{
				MessageBox.Show("Please select a salary record to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			if (MessageBox.Show("Are you sure you want to delete this salary record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				int salaryID = (int)dataGridView1.CurrentRow.Cells["salaryIDDataGridViewTextBoxColumn"].Value;
				try
				{
					salaryAdapter.Delete(salaryID, 0, "", 0, 0, 0, 0, 0, 0, 0, null);
					LoadSalaries();
					MessageBox.Show("Salary record deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error deleting record: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		}

		private void linklbDashboard_Click(object sender, EventArgs e) => this.Close();
	}
}