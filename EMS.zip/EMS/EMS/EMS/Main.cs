﻿using System;
using System.Windows.Forms;

namespace EMS
{
	public partial class Main : Form
	{
		private Form activeForm = null;

		public Main()
		{
			InitializeComponent();

			
			this.btnEmployee.Click += btnEmployee_Click;
			this.btnAttendance.Click += btnAttendance_Click;
			this.btnLeave.Click += btnLeave_Click;
			this.btnSalary.Click += btnSalary_Click;
			this.btnPerformance.Click += btnPerformance_Click;
			this.btnPasswordchange.Click += btnPasswordchange_Click;
			this.btnUser.Click += btnUser_Click;          
			this.btnLogout.Click += btnLogout_Click;
			this.panel1.Paint += panel1_Paint;
		}

		
		private void Main_Load(object sender, EventArgs e)
		{
			try
			{
				lbWelcome.Text = $"Welcome, {Session.Username} ({Session.Role})";
			}
			catch
			{
				lbWelcome.Text = "Welcome";
			}

			
			try
			{
				if (Session.Role != "Admin")
				{
					btnUser.Visible = false;        
													
				}
			}
			catch { }
		}

		
		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			
		}

		
		private void OpenChildForm(Form childForm)
		{
			if (activeForm != null)
			{
				activeForm.Close();
				activeForm.Dispose();
				activeForm = null;
			}
			activeForm = childForm;
			childForm.TopLevel = false;
			childForm.FormBorderStyle = FormBorderStyle.None;
			childForm.Dock = DockStyle.Fill;
			childForm.FormClosed += (s, args) =>
			{
				panel1.Controls.Remove(childForm);
				childForm.Dispose();
				activeForm = null;
			};
			panel1.Controls.Add(childForm);
			panel1.Tag = childForm;
			childForm.BringToFront();
			childForm.Show();
		}

		
		private void btnEmployee_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Employee());
		}

		private void btnAttendance_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Attendance());
		}

		private void btnLeave_Click(object sender, EventArgs e)
		{
			OpenChildForm(new LeaveRequest());
		}

		private void btnSalary_Click(object sender, EventArgs e)
		{
			OpenChildForm(new Salary());
		}

		private void btnPerformance_Click(object sender, EventArgs e)
		{
			OpenChildForm(new PerformanceReview());
		}

		private void btnPasswordchange_Click(object sender, EventArgs e)
		{
			PasswordChange pc = new PasswordChange();
			pc.ShowDialog();
		}

		
		private void btnUser_Click(object sender, EventArgs e)
		{
			OpenChildForm(new UserManagemnt());
		}

		private void btnLogout_Click(object sender, EventArgs e)
		{
			
			Session.UserID = 0;
			Session.Username = null;
			Session.Role = null;

			
			Login login = new Login();
			login.Show();
			this.Close();
		}
	}
}