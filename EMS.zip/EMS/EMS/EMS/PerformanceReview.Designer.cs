﻿namespace EMS
{
	partial class PerformanceReview
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lbEmployee = new System.Windows.Forms.Label();
			this.lbComments = new System.Windows.Forms.Label();
			this.lbPeriod = new System.Windows.Forms.Label();
			this.lbRating = new System.Windows.Forms.Label();
			this.lbReviewer = new System.Windows.Forms.Label();
			this.lbReviewDate = new System.Windows.Forms.Label();
			this.txtEmployee = new System.Windows.Forms.TextBox();
			this.txtReviwer = new System.Windows.Forms.TextBox();
			this.dtpReview = new System.Windows.Forms.DateTimePicker();
			this.nudRating = new System.Windows.Forms.NumericUpDown();
			this.cmdPeriod = new System.Windows.Forms.ComboBox();
			this.rtxtComments = new System.Windows.Forms.RichTextBox();
			this.btnAddReview = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnDelete = new System.Windows.Forms.Button();
			this.btnUpdate = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.reviewIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.reviewDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.reviewerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ratingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.commentsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.reviewPeriodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.performanceReviewsBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSet = new EMS.EMSDBDataSet();
			this.performanceReviewsTableAdapter = new EMS.EMSDBDataSetTableAdapters.PerformanceReviewsTableAdapter();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			((System.ComponentModel.ISupportInitialize)(this.nudRating)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.performanceReviewsBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).BeginInit();
			this.SuspendLayout();
			// 
			// lbEmployee
			// 
			this.lbEmployee.AutoSize = true;
			this.lbEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbEmployee.Location = new System.Drawing.Point(29, 20);
			this.lbEmployee.Name = "lbEmployee";
			this.lbEmployee.Size = new System.Drawing.Size(82, 20);
			this.lbEmployee.TabIndex = 0;
			this.lbEmployee.Text = "Employee";
			// 
			// lbComments
			// 
			this.lbComments.AutoSize = true;
			this.lbComments.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbComments.Location = new System.Drawing.Point(29, 186);
			this.lbComments.Name = "lbComments";
			this.lbComments.Size = new System.Drawing.Size(90, 20);
			this.lbComments.TabIndex = 2;
			this.lbComments.Text = "Comments";
			// 
			// lbPeriod
			// 
			this.lbPeriod.AutoSize = true;
			this.lbPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbPeriod.Location = new System.Drawing.Point(29, 149);
			this.lbPeriod.Name = "lbPeriod";
			this.lbPeriod.Size = new System.Drawing.Size(57, 20);
			this.lbPeriod.TabIndex = 3;
			this.lbPeriod.Text = "Period";
			this.lbPeriod.Click += new System.EventHandler(this.label3_Click);
			// 
			// lbRating
			// 
			this.lbRating.AutoSize = true;
			this.lbRating.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbRating.Location = new System.Drawing.Point(29, 118);
			this.lbRating.Name = "lbRating";
			this.lbRating.Size = new System.Drawing.Size(57, 20);
			this.lbRating.TabIndex = 4;
			this.lbRating.Text = "Rating";
			// 
			// lbReviewer
			// 
			this.lbReviewer.AutoSize = true;
			this.lbReviewer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbReviewer.Location = new System.Drawing.Point(29, 87);
			this.lbReviewer.Name = "lbReviewer";
			this.lbReviewer.Size = new System.Drawing.Size(78, 20);
			this.lbReviewer.TabIndex = 5;
			this.lbReviewer.Text = "Reviewer";
			// 
			// lbReviewDate
			// 
			this.lbReviewDate.AutoSize = true;
			this.lbReviewDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbReviewDate.Location = new System.Drawing.Point(29, 54);
			this.lbReviewDate.Name = "lbReviewDate";
			this.lbReviewDate.Size = new System.Drawing.Size(104, 20);
			this.lbReviewDate.TabIndex = 6;
			this.lbReviewDate.Text = "Review Date";
			// 
			// txtEmployee
			// 
			this.txtEmployee.Location = new System.Drawing.Point(161, 20);
			this.txtEmployee.Name = "txtEmployee";
			this.txtEmployee.Size = new System.Drawing.Size(151, 22);
			this.txtEmployee.TabIndex = 7;
			// 
			// txtReviwer
			// 
			this.txtReviwer.Location = new System.Drawing.Point(161, 87);
			this.txtReviwer.Name = "txtReviwer";
			this.txtReviwer.Size = new System.Drawing.Size(151, 22);
			this.txtReviwer.TabIndex = 8;
			// 
			// dtpReview
			// 
			this.dtpReview.Location = new System.Drawing.Point(161, 54);
			this.dtpReview.Name = "dtpReview";
			this.dtpReview.Size = new System.Drawing.Size(151, 22);
			this.dtpReview.TabIndex = 9;
			// 
			// nudRating
			// 
			this.nudRating.Location = new System.Drawing.Point(161, 116);
			this.nudRating.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
			this.nudRating.Name = "nudRating";
			this.nudRating.Size = new System.Drawing.Size(151, 22);
			this.nudRating.TabIndex = 10;
			// 
			// cmdPeriod
			// 
			this.cmdPeriod.FormattingEnabled = true;
			this.cmdPeriod.Items.AddRange(new object[] {
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026"});
			this.cmdPeriod.Location = new System.Drawing.Point(161, 145);
			this.cmdPeriod.Name = "cmdPeriod";
			this.cmdPeriod.Size = new System.Drawing.Size(151, 24);
			this.cmdPeriod.TabIndex = 11;
			// 
			// rtxtComments
			// 
			this.rtxtComments.Location = new System.Drawing.Point(33, 222);
			this.rtxtComments.Name = "rtxtComments";
			this.rtxtComments.Size = new System.Drawing.Size(451, 95);
			this.rtxtComments.TabIndex = 12;
			this.rtxtComments.Text = "";
			// 
			// btnAddReview
			// 
			this.btnAddReview.BackColor = System.Drawing.Color.PaleGreen;
			this.btnAddReview.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddReview.Location = new System.Drawing.Point(18, 335);
			this.btnAddReview.Name = "btnAddReview";
			this.btnAddReview.Size = new System.Drawing.Size(90, 35);
			this.btnAddReview.TabIndex = 13;
			this.btnAddReview.Text = "Add Review";
			this.btnAddReview.UseVisualStyleBackColor = false;
			// 
			// btnClear
			// 
			this.btnClear.BackColor = System.Drawing.Color.Gainsboro;
			this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnClear.Location = new System.Drawing.Point(363, 335);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(90, 35);
			this.btnClear.TabIndex = 14;
			this.btnClear.Text = "Clear";
			this.btnClear.UseVisualStyleBackColor = false;
			// 
			// btnDelete
			// 
			this.btnDelete.BackColor = System.Drawing.Color.Salmon;
			this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDelete.Location = new System.Drawing.Point(243, 335);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(90, 35);
			this.btnDelete.TabIndex = 15;
			this.btnDelete.Text = "Delete";
			this.btnDelete.UseVisualStyleBackColor = false;
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click_1);
			// 
			// btnUpdate
			// 
			this.btnUpdate.BackColor = System.Drawing.Color.Turquoise;
			this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnUpdate.Location = new System.Drawing.Point(129, 335);
			this.btnUpdate.Name = "btnUpdate";
			this.btnUpdate.Size = new System.Drawing.Size(90, 35);
			this.btnUpdate.TabIndex = 16;
			this.btnUpdate.Text = "Update";
			this.btnUpdate.UseVisualStyleBackColor = false;
			// 
			// dataGridView1
			// 
			this.dataGridView1.AutoGenerateColumns = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.reviewIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.reviewDateDataGridViewTextBoxColumn,
            this.reviewerDataGridViewTextBoxColumn,
            this.ratingDataGridViewTextBoxColumn,
            this.commentsDataGridViewTextBoxColumn,
            this.reviewPeriodDataGridViewTextBoxColumn});
			this.dataGridView1.DataSource = this.performanceReviewsBindingSource;
			this.dataGridView1.Location = new System.Drawing.Point(19, 396);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 51;
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(465, 167);
			this.dataGridView1.TabIndex = 17;
			// 
			// reviewIDDataGridViewTextBoxColumn
			// 
			this.reviewIDDataGridViewTextBoxColumn.DataPropertyName = "ReviewID";
			this.reviewIDDataGridViewTextBoxColumn.HeaderText = "ReviewID";
			this.reviewIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.reviewIDDataGridViewTextBoxColumn.Name = "reviewIDDataGridViewTextBoxColumn";
			this.reviewIDDataGridViewTextBoxColumn.ReadOnly = true;
			this.reviewIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// employeeIDDataGridViewTextBoxColumn
			// 
			this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
			this.employeeIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// reviewDateDataGridViewTextBoxColumn
			// 
			this.reviewDateDataGridViewTextBoxColumn.DataPropertyName = "ReviewDate";
			this.reviewDateDataGridViewTextBoxColumn.HeaderText = "ReviewDate";
			this.reviewDateDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.reviewDateDataGridViewTextBoxColumn.Name = "reviewDateDataGridViewTextBoxColumn";
			this.reviewDateDataGridViewTextBoxColumn.Width = 125;
			// 
			// reviewerDataGridViewTextBoxColumn
			// 
			this.reviewerDataGridViewTextBoxColumn.DataPropertyName = "Reviewer";
			this.reviewerDataGridViewTextBoxColumn.HeaderText = "Reviewer";
			this.reviewerDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.reviewerDataGridViewTextBoxColumn.Name = "reviewerDataGridViewTextBoxColumn";
			this.reviewerDataGridViewTextBoxColumn.Width = 125;
			// 
			// ratingDataGridViewTextBoxColumn
			// 
			this.ratingDataGridViewTextBoxColumn.DataPropertyName = "Rating";
			this.ratingDataGridViewTextBoxColumn.HeaderText = "Rating";
			this.ratingDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.ratingDataGridViewTextBoxColumn.Name = "ratingDataGridViewTextBoxColumn";
			this.ratingDataGridViewTextBoxColumn.Width = 125;
			// 
			// commentsDataGridViewTextBoxColumn
			// 
			this.commentsDataGridViewTextBoxColumn.DataPropertyName = "Comments";
			this.commentsDataGridViewTextBoxColumn.HeaderText = "Comments";
			this.commentsDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.commentsDataGridViewTextBoxColumn.Name = "commentsDataGridViewTextBoxColumn";
			this.commentsDataGridViewTextBoxColumn.Width = 125;
			// 
			// reviewPeriodDataGridViewTextBoxColumn
			// 
			this.reviewPeriodDataGridViewTextBoxColumn.DataPropertyName = "ReviewPeriod";
			this.reviewPeriodDataGridViewTextBoxColumn.HeaderText = "ReviewPeriod";
			this.reviewPeriodDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.reviewPeriodDataGridViewTextBoxColumn.Name = "reviewPeriodDataGridViewTextBoxColumn";
			this.reviewPeriodDataGridViewTextBoxColumn.Width = 125;
			// 
			// performanceReviewsBindingSource
			// 
			this.performanceReviewsBindingSource.DataMember = "PerformanceReviews";
			this.performanceReviewsBindingSource.DataSource = this.eMSDBDataSet;
			// 
			// eMSDBDataSet
			// 
			this.eMSDBDataSet.DataSetName = "EMSDBDataSet";
			this.eMSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// performanceReviewsTableAdapter
			// 
			this.performanceReviewsTableAdapter.ClearBeforeFill = true;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(347, 20);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 19;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// PerformanceReview
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(532, 577);
			this.Controls.Add(this.linklbDashboard);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.btnUpdate);
			this.Controls.Add(this.btnDelete);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.btnAddReview);
			this.Controls.Add(this.rtxtComments);
			this.Controls.Add(this.cmdPeriod);
			this.Controls.Add(this.nudRating);
			this.Controls.Add(this.dtpReview);
			this.Controls.Add(this.txtReviwer);
			this.Controls.Add(this.txtEmployee);
			this.Controls.Add(this.lbReviewDate);
			this.Controls.Add(this.lbReviewer);
			this.Controls.Add(this.lbRating);
			this.Controls.Add(this.lbPeriod);
			this.Controls.Add(this.lbComments);
			this.Controls.Add(this.lbEmployee);
			this.Name = "PerformanceReview";
			this.Text = "PerformanceReview";
			this.Load += new System.EventHandler(this.PerformanceReview_Load);
			((System.ComponentModel.ISupportInitialize)(this.nudRating)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.performanceReviewsBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lbEmployee;
		private System.Windows.Forms.Label lbComments;
		private System.Windows.Forms.Label lbPeriod;
		private System.Windows.Forms.Label lbRating;
		private System.Windows.Forms.Label lbReviewer;
		private System.Windows.Forms.Label lbReviewDate;
		private System.Windows.Forms.TextBox txtEmployee;
		private System.Windows.Forms.TextBox txtReviwer;
		private System.Windows.Forms.DateTimePicker dtpReview;
		private System.Windows.Forms.NumericUpDown nudRating;
		private System.Windows.Forms.ComboBox cmdPeriod;
		private System.Windows.Forms.RichTextBox rtxtComments;
		private System.Windows.Forms.Button btnAddReview;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnUpdate;
		private System.Windows.Forms.DataGridView dataGridView1;
		private EMSDBDataSet eMSDBDataSet;
		private System.Windows.Forms.BindingSource performanceReviewsBindingSource;
		private EMSDBDataSetTableAdapters.PerformanceReviewsTableAdapter performanceReviewsTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn reviewIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn reviewDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn reviewerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ratingDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn commentsDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn reviewPeriodDataGridViewTextBoxColumn;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}