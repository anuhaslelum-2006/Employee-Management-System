﻿namespace EMS
{
	partial class Attendance
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.lbEmployee = new System.Windows.Forms.Label();
			this.lbRemarks = new System.Windows.Forms.Label();
			this.lbStatus = new System.Windows.Forms.Label();
			this.lbDate = new System.Windows.Forms.Label();
			this.txtEmployee = new System.Windows.Forms.TextBox();
			this.txtRemarks = new System.Windows.Forms.TextBox();
			this.dtpDateAttendance = new System.Windows.Forms.DateTimePicker();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.cmdStatus = new System.Windows.Forms.ComboBox();
			this.btnMark = new System.Windows.Forms.Button();
			this.btnSelected = new System.Windows.Forms.Button();
			this.panelAttendance = new System.Windows.Forms.Panel();
			this.dgvAttendance = new System.Windows.Forms.DataGridView();
			this.attendanceIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.attendanceDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.remarksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.attendanceBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.eMSDBDataSet = new EMS.EMSDBDataSet();
			this.attendanceTableAdapter = new EMS.EMSDBDataSetTableAdapters.AttendanceTableAdapter();
			this.linklbDashboard = new System.Windows.Forms.LinkLabel();
			this.panelAttendance.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvAttendance)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.attendanceBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSetBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).BeginInit();
			this.SuspendLayout();
			// 
			// lbEmployee
			// 
			this.lbEmployee.AutoSize = true;
			this.lbEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbEmployee.Location = new System.Drawing.Point(27, 28);
			this.lbEmployee.Name = "lbEmployee";
			this.lbEmployee.Size = new System.Drawing.Size(82, 20);
			this.lbEmployee.TabIndex = 0;
			this.lbEmployee.Text = "Employee";
			// 
			// lbRemarks
			// 
			this.lbRemarks.AutoSize = true;
			this.lbRemarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbRemarks.Location = new System.Drawing.Point(27, 124);
			this.lbRemarks.Name = "lbRemarks";
			this.lbRemarks.Size = new System.Drawing.Size(76, 20);
			this.lbRemarks.TabIndex = 1;
			this.lbRemarks.Text = "Remarks";
			// 
			// lbStatus
			// 
			this.lbStatus.AutoSize = true;
			this.lbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbStatus.Location = new System.Drawing.Point(27, 92);
			this.lbStatus.Name = "lbStatus";
			this.lbStatus.Size = new System.Drawing.Size(57, 20);
			this.lbStatus.TabIndex = 2;
			this.lbStatus.Text = "Status";
			// 
			// lbDate
			// 
			this.lbDate.AutoSize = true;
			this.lbDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbDate.Location = new System.Drawing.Point(27, 60);
			this.lbDate.Name = "lbDate";
			this.lbDate.Size = new System.Drawing.Size(45, 20);
			this.lbDate.TabIndex = 3;
			this.lbDate.Text = "Date";
			// 
			// txtEmployee
			// 
			this.txtEmployee.Location = new System.Drawing.Point(144, 29);
			this.txtEmployee.Name = "txtEmployee";
			this.txtEmployee.Size = new System.Drawing.Size(150, 22);
			this.txtEmployee.TabIndex = 4;
			// 
			// txtRemarks
			// 
			this.txtRemarks.Location = new System.Drawing.Point(144, 118);
			this.txtRemarks.Name = "txtRemarks";
			this.txtRemarks.Size = new System.Drawing.Size(150, 22);
			this.txtRemarks.TabIndex = 5;
			// 
			// dtpDateAttendance
			// 
			this.dtpDateAttendance.Location = new System.Drawing.Point(144, 60);
			this.dtpDateAttendance.Name = "dtpDateAttendance";
			this.dtpDateAttendance.Size = new System.Drawing.Size(150, 22);
			this.dtpDateAttendance.TabIndex = 6;
			// 
			// cmdStatus
			// 
			this.cmdStatus.FormattingEnabled = true;
			this.cmdStatus.Items.AddRange(new object[] {
            "Present",
            "Absent"});
			this.cmdStatus.Location = new System.Drawing.Point(144, 88);
			this.cmdStatus.Name = "cmdStatus";
			this.cmdStatus.Size = new System.Drawing.Size(150, 24);
			this.cmdStatus.TabIndex = 7;
			// 
			// btnMark
			// 
			this.btnMark.BackColor = System.Drawing.Color.PaleGreen;
			this.btnMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnMark.Location = new System.Drawing.Point(343, 28);
			this.btnMark.Name = "btnMark";
			this.btnMark.Size = new System.Drawing.Size(160, 40);
			this.btnMark.TabIndex = 8;
			this.btnMark.Text = "Mark Attendance";
			this.btnMark.UseVisualStyleBackColor = false;
			// 
			// btnSelected
			// 
			this.btnSelected.BackColor = System.Drawing.Color.Orange;
			this.btnSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSelected.Location = new System.Drawing.Point(343, 92);
			this.btnSelected.Name = "btnSelected";
			this.btnSelected.Size = new System.Drawing.Size(160, 40);
			this.btnSelected.TabIndex = 9;
			this.btnSelected.Text = "Delete Selected";
			this.btnSelected.UseVisualStyleBackColor = false;
			// 
			// panelAttendance
			// 
			this.panelAttendance.Controls.Add(this.btnSelected);
			this.panelAttendance.Controls.Add(this.btnMark);
			this.panelAttendance.Controls.Add(this.cmdStatus);
			this.panelAttendance.Controls.Add(this.dtpDateAttendance);
			this.panelAttendance.Controls.Add(this.txtRemarks);
			this.panelAttendance.Controls.Add(this.txtEmployee);
			this.panelAttendance.Controls.Add(this.lbDate);
			this.panelAttendance.Controls.Add(this.lbStatus);
			this.panelAttendance.Controls.Add(this.lbRemarks);
			this.panelAttendance.Controls.Add(this.lbEmployee);
			this.panelAttendance.Location = new System.Drawing.Point(52, 28);
			this.panelAttendance.Name = "panelAttendance";
			this.panelAttendance.Size = new System.Drawing.Size(561, 205);
			this.panelAttendance.TabIndex = 0;
			// 
			// dgvAttendance
			// 
			this.dgvAttendance.AutoGenerateColumns = false;
			this.dgvAttendance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvAttendance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.attendanceIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.attendanceDateDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.remarksDataGridViewTextBoxColumn});
			this.dgvAttendance.DataSource = this.attendanceBindingSource;
			this.dgvAttendance.Location = new System.Drawing.Point(52, 267);
			this.dgvAttendance.Name = "dgvAttendance";
			this.dgvAttendance.RowHeadersWidth = 51;
			this.dgvAttendance.RowTemplate.Height = 24;
			this.dgvAttendance.Size = new System.Drawing.Size(561, 201);
			this.dgvAttendance.TabIndex = 1;
			// 
			// attendanceIDDataGridViewTextBoxColumn
			// 
			this.attendanceIDDataGridViewTextBoxColumn.DataPropertyName = "AttendanceID";
			this.attendanceIDDataGridViewTextBoxColumn.HeaderText = "AttendanceID";
			this.attendanceIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.attendanceIDDataGridViewTextBoxColumn.Name = "attendanceIDDataGridViewTextBoxColumn";
			this.attendanceIDDataGridViewTextBoxColumn.ReadOnly = true;
			this.attendanceIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// employeeIDDataGridViewTextBoxColumn
			// 
			this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
			this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
			this.employeeIDDataGridViewTextBoxColumn.Width = 125;
			// 
			// attendanceDateDataGridViewTextBoxColumn
			// 
			this.attendanceDateDataGridViewTextBoxColumn.DataPropertyName = "AttendanceDate";
			this.attendanceDateDataGridViewTextBoxColumn.HeaderText = "AttendanceDate";
			this.attendanceDateDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.attendanceDateDataGridViewTextBoxColumn.Name = "attendanceDateDataGridViewTextBoxColumn";
			this.attendanceDateDataGridViewTextBoxColumn.Width = 125;
			// 
			// statusDataGridViewTextBoxColumn
			// 
			this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
			this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
			this.statusDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
			this.statusDataGridViewTextBoxColumn.Width = 125;
			// 
			// remarksDataGridViewTextBoxColumn
			// 
			this.remarksDataGridViewTextBoxColumn.DataPropertyName = "Remarks";
			this.remarksDataGridViewTextBoxColumn.HeaderText = "Remarks";
			this.remarksDataGridViewTextBoxColumn.MinimumWidth = 6;
			this.remarksDataGridViewTextBoxColumn.Name = "remarksDataGridViewTextBoxColumn";
			this.remarksDataGridViewTextBoxColumn.Width = 125;
			// 
			// attendanceBindingSource
			// 
			this.attendanceBindingSource.DataMember = "Attendance";
			this.attendanceBindingSource.DataSource = this.eMSDBDataSetBindingSource;
			// 
			// eMSDBDataSetBindingSource
			// 
			this.eMSDBDataSetBindingSource.DataSource = this.eMSDBDataSet;
			this.eMSDBDataSetBindingSource.Position = 0;
			// 
			// eMSDBDataSet
			// 
			this.eMSDBDataSet.DataSetName = "EMSDBDataSet";
			this.eMSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// attendanceTableAdapter
			// 
			this.attendanceTableAdapter.ClearBeforeFill = true;
			// 
			// linklbDashboard
			// 
			this.linklbDashboard.AutoSize = true;
			this.linklbDashboard.Location = new System.Drawing.Point(12, 9);
			this.linklbDashboard.Name = "linklbDashboard";
			this.linklbDashboard.Size = new System.Drawing.Size(137, 16);
			this.linklbDashboard.TabIndex = 19;
			this.linklbDashboard.TabStop = true;
			this.linklbDashboard.Text = "Return To Dashboard";
			// 
			// Attendance
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(672, 490);
			this.Controls.Add(this.linklbDashboard);
			this.Controls.Add(this.dgvAttendance);
			this.Controls.Add(this.panelAttendance);
			this.Name = "Attendance";
			this.Text = "Attendance";
			this.Load += new System.EventHandler(this.Attendance_Load);
			this.panelAttendance.ResumeLayout(false);
			this.panelAttendance.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvAttendance)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.attendanceBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSetBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.eMSDBDataSet)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.DateTimePicker dtpDateAttendance;
		private System.Windows.Forms.TextBox txtRemarks;
		private System.Windows.Forms.TextBox txtEmployee;
		private System.Windows.Forms.Label lbDate;
		private System.Windows.Forms.Label lbStatus;
		private System.Windows.Forms.Label lbRemarks;
		private System.Windows.Forms.Label lbEmployee;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.ComboBox cmdStatus;
		private System.Windows.Forms.Button btnMark;
		private System.Windows.Forms.Button btnSelected;
		private System.Windows.Forms.Panel panelAttendance;
		private System.Windows.Forms.DataGridView dgvAttendance;
		private System.Windows.Forms.BindingSource eMSDBDataSetBindingSource;
		private EMSDBDataSet eMSDBDataSet;
		private System.Windows.Forms.BindingSource attendanceBindingSource;
		private EMSDBDataSetTableAdapters.AttendanceTableAdapter attendanceTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn attendanceIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn attendanceDateDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn remarksDataGridViewTextBoxColumn;
		private System.Windows.Forms.LinkLabel linklbDashboard;
	}
}