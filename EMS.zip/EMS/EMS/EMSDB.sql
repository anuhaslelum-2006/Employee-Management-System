CREATE DATABASE EMSDB;
GO
USE EMSDB;
GO
CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Position NVARCHAR(50) NULL,
    Email NVARCHAR(100) NULL,
    Phone NVARCHAR(20) NULL,
    HireDate DATE NULL,
    BasicSalary DECIMAL(18,2) NOT NULL DEFAULT 0
);
GO
CREATE TABLE Attendance (
    AttendanceID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    Status NVARCHAR(20) NOT NULL,
    Remarks NVARCHAR(100) NULL,
    CONSTRAINT FK_Attendance_Employee FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID) ON DELETE CASCADE,
    CONSTRAINT CK_Attendance_Status CHECK (Status IN ('Present', 'Absent', 'HalfDay', 'Leave')),
    CONSTRAINT UQ_Attendance_EmployeeDate UNIQUE (EmployeeID, AttendanceDate)
);
GO
CREATE TABLE LeaveRequests (
    LeaveID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    LeaveType NVARCHAR(30) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    Reason NVARCHAR(200) NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Pending',
    CONSTRAINT FK_LeaveRequests_Employee FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID) ON DELETE CASCADE,
    CONSTRAINT CK_LeaveRequests_Status CHECK (Status IN ('Pending', 'Approved', 'Rejected'))
);
GO
CREATE TABLE Salary (
    SalaryID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    MonthYear NVARCHAR(7) NOT NULL,
    BasicSalary DECIMAL(18,2) NOT NULL,
    TotalDays INT DEFAULT 30,
    PresentDays INT DEFAULT 0,
    LeaveDays INT DEFAULT 0,
    Deductions DECIMAL(18,2) DEFAULT 0,
    Bonus DECIMAL(18,2) DEFAULT 0,
    NetSalary DECIMAL(18,2) DEFAULT 0,
    GeneratedDate DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_Salary_Employee FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID) ON DELETE CASCADE
);
GO
CREATE TABLE PerformanceReviews (
    ReviewID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    ReviewDate DATE NOT NULL,
    Reviewer NVARCHAR(100) NULL,
    Rating INT NOT NULL,
    Comments NVARCHAR(500) NULL,
    ReviewPeriod NVARCHAR(50) NOT NULL,
    CONSTRAINT FK_PerformanceReviews_Employee FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID) ON DELETE CASCADE,
    CONSTRAINT CK_PerformanceReviews_Rating CHECK (Rating BETWEEN 1 AND 5)
);
GO
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) UNIQUE NOT NULL,
    PasswordHash NVARCHAR(128) NOT NULL,
    Role NVARCHAR(20) NOT NULL DEFAULT 'User',
    CONSTRAINT CK_Users_Role CHECK (Role IN ('Admin', 'User'))
);
GO
INSERT INTO Employees (FirstName, LastName, Position, Email, Phone, HireDate, BasicSalary) VALUES
('Nuwan', 'Hirantha', 'IT Manager', 'nuwan.h@example.com', '0712345678', '2020-01-15', 120000.00),
('Amali', 'Perera', 'HR Officer', 'amali.p@example.com', '0723456789', '2021-03-10', 75000.00),
('Kasun', 'Jayawardena', 'Software Developer', 'kasun.j@example.com', '0771234567', '2022-06-20', 85000.00),
('Dilini', 'Fernando', 'Accountant', 'dilini.f@example.com', '0782345678', '2019-11-01', 90000.00),
('Chamara', 'Silva', 'Marketing Executive', 'chamara.s@example.com', '0763456789', '2023-02-14', 65000.00),
('Nadeesha', 'Bandara', 'Operations Coordinator', 'nadeesha.b@example.com', '0754567890', '2020-09-25', 70000.00);
GO
INSERT INTO Attendance (EmployeeID, AttendanceDate, Status, Remarks) VALUES
(1, '2025-03-01', 'Present', NULL),
(1, '2025-03-02', 'Present', NULL),
(1, '2025-03-03', 'Absent', 'Doctor appointment'),
(2, '2025-03-01', 'Present', NULL),
(2, '2025-03-02', 'Leave', 'Annual leave'),
(3, '2025-03-01', 'HalfDay', 'Morning only'),
(3, '2025-03-02', 'Present', NULL);
GO
INSERT INTO LeaveRequests (EmployeeID, LeaveType, StartDate, EndDate, Reason, Status) VALUES
(1, 'Annual', '2025-04-10', '2025-04-15', 'Family vacation', 'Pending'),
(2, 'Sick', '2025-03-20', '2025-03-21', 'Flu', 'Approved'),
(3, 'Casual', '2025-05-05', '2025-05-05', 'Personal work', 'Pending');
GO
INSERT INTO Salary (EmployeeID, MonthYear, BasicSalary, TotalDays, PresentDays, LeaveDays, Deductions, Bonus, NetSalary, GeneratedDate) VALUES
(1, '2025-03', 120000.00, 30, 28, 1, 4000.00, 5000.00, 121000.00, GETDATE()),
(2, '2025-03', 75000.00, 30, 29, 1, 2500.00, 0.00, 72500.00, GETDATE());
GO
INSERT INTO PerformanceReviews (EmployeeID, ReviewDate, Reviewer, Rating, Comments, ReviewPeriod) VALUES
(1, '2025-02-28', 'Admin', 5, 'Excellent performance, exceeded expectations.', 'Q1 2025'),
(2, '2025-02-28', 'Admin', 4, 'Good teamwork and attendance.', 'Q1 2025'),
(3, '2024-12-15', 'Nuwan Hirantha', 4, 'Solid coding skills, needs more documentation.', 'Annual 2024');
GO
INSERT INTO Users (Username, PasswordHash, Role) VALUES
('admin', 'admin123', 'Admin'),
('user1', 'pass123', 'User'),
('manager', 'manager456', 'Admin');
GO
